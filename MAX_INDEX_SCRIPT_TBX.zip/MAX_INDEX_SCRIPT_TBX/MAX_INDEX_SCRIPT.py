# -*- coding: utf-8 -*-
"""
The following source code implements the Forward Pinellas Multimodal Accessibility Index or MAX Index, which serves as a multimodal alternative to traditional roadway level of service or LOS.
This program was made public so that it could hopefully be forked, modified, and improved upon over time by other municipalities across the US. 

PART 1:

This process generates unique fields for line data imported within the Forward Pinellas MAX Index

The following fields will be created and initially set equal to zero. See the calculate fields portion in PART 2 for details on each field and how each is calculated: 

BL_MAX 
BL_QTR 
BL_HLF 
BL_TOT 

HW_MAX 
HW_QTR 
HW_HLF 
HW_TOT 

LOS_MAX 
LOS_QTR 
LOS_HLF 
LOS_TOT 

VC_MAX 
VC_QTR 
VC_HLF 
VC_TOT

TIPL_MAX
TIPL_QTR
TIPL_HLF
TIPL_TOT

TRL_MAX
TRL_QTR 
TRL_HLF
TRL_TOT 

SHR_MAX 
SHR_QTR 
SHR_HLF 
SHR_TOT  

TOT_LINE
"""
import arcpy

Workspace = arcpy.GetParameterAsText(0) # Define the GDB you are working in
maxInputFeaturesLines = arcpy.GetParameterAsText(1) # input the exported MAX Index fishnet feature

def createFieldsLines():  # Create Unique Fields for the MAX Index grids associated with line data inputs

    # To allow overwriting outputs change overwriteOutput option to True.
    arcpy.env.overwriteOutput = True

    MAX_INDEX_LINES = maxInputFeaturesLines

    # Process: Add Field (Add Field) (management)
    MAX_INDEX_LINES_21_ = arcpy.management.AddField(in_table=MAX_INDEX_LINES, field_name="BL_MAX", field_type="DOUBLE", field_precision=6, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (2) (Add Field) (management)
    MAX_INDEX_LINES_2_ = arcpy.management.AddField(in_table=MAX_INDEX_LINES_21_, field_name="BL_QTR", field_type="DOUBLE", field_precision=6, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (3) (Add Field) (management)
    if MAX_INDEX_LINES_2_:
        MAX_INDEX_LINES_3_ = arcpy.management.AddField(in_table=MAX_INDEX_LINES_2_, field_name="BL_HLF", field_type="DOUBLE", field_precision=6, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (4) (Add Field) (management)
    if MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_3_:
        MAX_INDEX_LINES_4_ = arcpy.management.AddField(in_table=MAX_INDEX_LINES_3_, field_name="BL_TOT", field_type="DOUBLE", field_precision=6, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (5) (Add Field) (management)
        MAX_INDEX_LINES_5_ = arcpy.management.AddField(in_table=MAX_INDEX_LINES_4_, field_name="HW_MAX", field_type="DOUBLE", field_precision=6, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (6) (Add Field) (management)
        MAX_INDEX_LINES_6_ = arcpy.management.AddField(in_table=MAX_INDEX_LINES_5_, field_name="HW_QTR", field_type="DOUBLE", field_precision=6, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (7) (Add Field) (management)
        MAX_INDEX_LINES_9_ = arcpy.management.AddField(in_table=MAX_INDEX_LINES_6_, field_name="HW_HLF", field_type="DOUBLE", field_precision=6, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (8) (Add Field) (management)
        MAX_INDEX_LINES_7_ = arcpy.management.AddField(in_table=MAX_INDEX_LINES_9_, field_name="HW_TOT", field_type="DOUBLE", field_precision=6, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (9) (Add Field) (management)
        MAX_INDEX_LINES_8_ = arcpy.management.AddField(in_table=MAX_INDEX_LINES_7_, field_name="LOS_MAX", field_type="DOUBLE", field_precision=6, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (10) (Add Field) (management)
        MAX_INDEX_LINES_10_ = arcpy.management.AddField(in_table=MAX_INDEX_LINES_8_, field_name="LOS_QTR", field_type="DOUBLE", field_precision=6, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (11) (Add Field) (management)
        MAX_INDEX_LINES_11_ = arcpy.management.AddField(in_table=MAX_INDEX_LINES_10_, field_name="LOS_HLF", field_type="DOUBLE", field_precision=6, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (12) (Add Field) (management)
        MAX_INDEX_LINES_12_ = arcpy.management.AddField(in_table=MAX_INDEX_LINES_11_, field_name="LOS_TOT", field_type="DOUBLE", field_precision=6, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (13) (Add Field) (management)
        MAX_INDEX_LINES_13_ = arcpy.management.AddField(in_table=MAX_INDEX_LINES_12_, field_name="VC_MAX", field_type="DOUBLE", field_precision=6, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (14) (Add Field) (management)
        MAX_INDEX_LINES_14_ = arcpy.management.AddField(in_table=MAX_INDEX_LINES_13_, field_name="VC_QTR", field_type="DOUBLE", field_precision=6, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (15) (Add Field) (management)
        MAX_INDEX_LINES_15_ = arcpy.management.AddField(in_table=MAX_INDEX_LINES_14_, field_name="VC_HLF", field_type="DOUBLE", field_precision=6, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (16) (Add Field) (management)
        MAX_INDEX_LINES_16_ = arcpy.management.AddField(in_table=MAX_INDEX_LINES_15_, field_name="VC_TOT", field_type="DOUBLE", field_precision=6, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (17) (Add Field) (management)
        MAX_INDEX_LINES_17_ = arcpy.management.AddField(in_table=MAX_INDEX_LINES_16_, field_name="TIPL_MAX", field_type="DOUBLE", field_precision=6, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (18) (Add Field) (management)
        MAX_INDEX_LINES_18_ = arcpy.management.AddField(in_table=MAX_INDEX_LINES_17_, field_name="TIPL_QTR", field_type="DOUBLE", field_precision=6, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (19) (Add Field) (management)
        MAX_INDEX_LINES_19_ = arcpy.management.AddField(in_table=MAX_INDEX_LINES_18_, field_name="TIPL_HLF", field_type="DOUBLE", field_precision=6, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (20) (Add Field) (management)
        MAX_INDEX_LINES_20_ = arcpy.management.AddField(in_table=MAX_INDEX_LINES_19_, field_name="TIPL_TOT", field_type="DOUBLE", field_precision=6, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (21) (Add Field) (management)
        MAX_INDEX_LINES_30_ = arcpy.management.AddField(in_table=MAX_INDEX_LINES_20_, field_name="TRL_MAX", field_type="DOUBLE", field_precision=6, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (22) (Add Field) (management)
        MAX_INDEX_LINES_22_ = arcpy.management.AddField(in_table=MAX_INDEX_LINES_30_, field_name="TRL_QTR", field_type="DOUBLE", field_precision=6, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (23) (Add Field) (management)
        MAX_INDEX_LINES_23_ = arcpy.management.AddField(in_table=MAX_INDEX_LINES_22_, field_name="TRL_HLF", field_type="DOUBLE", field_precision=6, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (24) (Add Field) (management)
        MAX_INDEX_LINES_24_ = arcpy.management.AddField(in_table=MAX_INDEX_LINES_23_, field_name="TRL_TOT", field_type="DOUBLE", field_precision=6, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (25) (Add Field) (management)
        MAX_INDEX_LINES_25_ = arcpy.management.AddField(in_table=MAX_INDEX_LINES_24_, field_name="SHR_MAX", field_type="DOUBLE", field_precision=6, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (26) (Add Field) (management)
        MAX_INDEX_LINES_26_ = arcpy.management.AddField(in_table=MAX_INDEX_LINES_25_, field_name="SHR_QTR", field_type="DOUBLE", field_precision=6, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (27) (Add Field) (management)
        MAX_INDEX_LINES_27_ = arcpy.management.AddField(in_table=MAX_INDEX_LINES_26_, field_name="SHR_HLF", field_type="DOUBLE", field_precision=6, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (28) (Add Field) (management)
        MAX_INDEX_LINES_28_ = arcpy.management.AddField(in_table=MAX_INDEX_LINES_27_, field_name="SHR_TOT", field_type="DOUBLE", field_precision=6, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (33) (Add Field) (management)
        MAX_INDEX_LINES_29_ = arcpy.management.AddField(in_table=MAX_INDEX_LINES_28_, field_name="TOT_LIN", field_type="DOUBLE", field_precision=6, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Calculate Fields (multiple) (Calculate Fields (multiple)) (management)
        MAX_INDEX_LINES_35_ = arcpy.management.CalculateFields(in_table=MAX_INDEX_LINES_29_, expression_type="PYTHON3", fields=[["BL_QTR", "0"], ["BL_HLF", "0"], ["BL_MAX", "0"], ["BL_TOT", "0"], ["HW_MAX", "0"], ["HW_QTR", "0"], ["HW_HLF", "0"], ["HW_TOT", "0"], ["LOS_MAX", "0"], ["LOS_QTR", "0"], ["LOS_HLF", "0"], ["LOS_TOT", "0"], ["VC_MAX", "0"], ["VC_QTR", "0"], ["VC_HLF", "0"], ["VC_TOT", "0"], ["TIPL_MAX", "0"], ["TIPL_QTR", "0"], ["TIPL_HLF", "0"], ["TIPL_TOT", "0"], ["TRL_MAX", "0"], ["TRL_QTR", "0"], ["TRL_HLF", "0"], ["TRL_TOT", "0"], ["SHR_MAX", "0"], ["SHR_QTR", "0"], ["SHR_HLF", "0"], ["SHR_TOT", "0"], ["TOT_LIN", "0"]], code_block="", enforce_domains="NO_ENFORCE_DOMAINS")[0]




"""
PART 2: 

This process calculates fields for the MAX Index grid associated with line data.

BL_MAX = Score associated with the presence of bike lanes directly in a grid cell. Maximum score if bike lanes are present is 3
BL_QTR = Score associated with the presence of bike lanes within a quarter mile of the grid cell. Maximum score if bike lanes are present within a quarter mile is 1.5
BL_HLF = Score associated with the presence of bike lanes within a half mile of the grid cell. Maximum score if bike lanes are present within a half mile is 0.75
BL_TOT = The sum of BL_MAX (multiplied by the number of features present in the grid cell), BL_QTR, and BL_TOT. 

HW_MAX = Score associated with the presence of bus headways of 30 minutes or less directly in a grid cell. Maximum score if 30 minute headways are present is 3
HW_QTR = Score associated with the presence of bus headways of 30 minutes or less within a quarter mile of the grid cell. Maximum score if 30 minute headways are present within a quarter mile is 1.5
HW_HLF = Score associated with the presence of bus headways of 30 minutes or less within a half mile of the grid cell. Maximum score if 30 minute headways are present within a half mile is 0.75
HW_TOT = The sum of BL_MAX (multiplied by the number of features present in the grid cell), BL_QTR, and BL_TOT.

LOS_MAX = Score associated with the presence of roadways with a LOS score of D or better directly in a grid cell. Maximum score if an LOS score of D is present is 1.5
LOS_QTR = Score associated with the presence of roadways with a LOS score of D or better within a quarter mile of the grid cell. Maximum score if an LOS score of D is present within a quarter mile is 0.75
LOS_HLF = Score associated with the presence of roadways with a LOS score of D or better within a half mile of the grid cell. Maximum score if an LOS score of D is present within a half mile is 0.375
LOS_TOT = The sum of LOS_MAX (multiplied by the number of features present in the grid cell), LOS_QTR, and LOS_TOT.

VC_MAX = Score associated with the presence of roadways with a volume to capacity ratio better than the community average directly in a grid cell. Maximum score if an adequate VC ratio is present is 1.5
VC_QTR = Score associated with the presence of roadways with a volume to capacity ratio better than the community average within a quarter mile of the grid cell. Maximum score if an adequate VC ratio is present within a quarter mile is 0.75
VC_HLF = Score associated with the presence of roadways with a volume to capacity ratio better than the community average within a half mile of the grid cell. Maximum score if an adequate VC ratio is present within a half mile is 0.375
VC_TOT = The sum of VC_MAX (multiplied by the number of features present in the grid cell), VC_QTR, and VC_TOT.

TIPL_MAX = Score associated with the presence of TIP Project Line Data directly in a grid cell. Maximum score if TIP Lines are present is 1
TIPL_QTR = Score associated with the presence of TIP Project Line Data within a quarter mile of the grid cell. Maximum score if TIP Lines are present within a quarter mile is 0.5
TIPL_HLF = Score associated with the presence of TIP Project Line Data within a half mile of the grid cell. Maximum score if TIP Lines are present within a half mile is 0.25
TIPL_TOT = The sum of TIPL_MAX (multiplied by the number of features present in the grid cell), TIPL_QTR, and TIPL_TOT.

TRL_MAX = Score associated with the presence of trails directly in a grid cell. Maximum score if trails are present is 3
TRL_QTR = Score associated with the presence of trails within a quarter mile of the grid cell. Maximum score if trails are present within a quarter mile is 1.5
TRL_HLF = Score associated with the presence of trails within a half mile of the grid cell. Maximum score if trails are present within a half mile is 0.75
TRL_TOT = The sum of TRL_MAX (multiplied by the number of features present in the grid cell), TRL_QTR, and TRL_TOT. 

SHR_MAX = Score associated with the presence of sharrows directly in a grid cell. Maximum score if trails are present is 1
SHR_QTR = Score associated with the presence of sharrows within a quarter mile of the grid cell. Maximum score if trails are present within a quarter mile is 0.5
SHR_HLF = Score associated with the presence of sharrows within a half mile of the grid cell. Maximum score if trails are present within a half mile is 0.25
SHR_TOT = The sum of TRL_MAX (multiplied by the number of features present in the grid cell), TRL_QTR, and TRL_TOT.

TOT_LINE = sum of the following: BL_TOT, HW_TOT, LOS_TOT, VC_TOT, TIPL_TOT, TRL_TOT, SHR_TOT

Additional field calculation scripts are in place to prevent fields from being double counted in total point calculation.

"""

bikeLanes = arcpy.GetParameterAsText(2) # input bike lanes feature
headways_30min_Or_Less = arcpy.GetParameterAsText(3) # input headways of 30 minutes or less feature
los_D_OR_Better = arcpy.GetParameterAsText(4) # input roadways feature that contain only those roadways with an LOS grade of D or better
vc_Ratio_Better_Thn_Avg = arcpy.GetParameterAsText(5) # input roadways feature that contain only those roadways with a Volume to Capacity Ratio better than the community you are studyings average
tip_Lines = arcpy.GetParameterAsText(6) # input TIP projects line data
trails = arcpy.GetParameterAsText(7) # input trails data
sharrows = arcpy.GetParameterAsText(8) # input sharrow data

def calculateFieldsLines():  # Calculates each newly created field for the MAX Index lines grid

    # To allow overwriting outputs change overwriteOutput option to True.
    arcpy.env.overwriteOutput = True

    # Model Environment settings
    with arcpy.EnvManager(scratchWorkspace=Workspace):
        MAX_INDEX_LINES = maxInputFeaturesLines
        Bike_Lanes = bikeLanes
        MAX_INDEX_LINES_10_ = maxInputFeaturesLines
        Headways_30 = headways_30min_Or_Less
        MAX_INDEX_LINES_18_ = maxInputFeaturesLines
        LOS = los_D_OR_Better
        MAX_INDEX_LINES_32_ = maxInputFeaturesLines
        TIP_LINES = tip_Lines
        MAX_INDEX_LINES_64_ = maxInputFeaturesLines
        MAX_INDEX_LINES_28_ = maxInputFeaturesLines
        MAX_INDEX_LINES_58_ = maxInputFeaturesLines
        VC_RATIO_2_ = vc_Ratio_Better_Thn_Avg
        MAX_INDEX_LINES_40_ = maxInputFeaturesLines
        TRAILS = trails
        MAX_INDEX_LINES_43_ = maxInputFeaturesLines
        Sharrows = sharrows
        MAX_INDEX_LINES_57_ = maxInputFeaturesLines
        MAX_INDEX_LINES_29_ = maxInputFeaturesLines
        MAX_INDEX_LINES_31_ = maxInputFeaturesLines
        Sharrows_2_ = sharrows
        MAX_INDEX_LINES_35_ = maxInputFeaturesLines
        MAX_INDEX_LINES_37_ = maxInputFeaturesLines
        TRAILS_2_ = trails
        MAX_INDEX_LINES_60_ = maxInputFeaturesLines
        MAX_INDEX_LINES_62_ = maxInputFeaturesLines
        TIP_LINES_2_ = tip_Lines
        MAX_INDEX_LINES_67_ = maxInputFeaturesLines
        MAX_INDEX_LINES_68_ = maxInputFeaturesLines
        VC_RATIO = vc_Ratio_Better_Thn_Avg
        MAX_INDEX_LINES_69_ = maxInputFeaturesLines
        MAX_INDEX_LINES_70_ = maxInputFeaturesLines
        LOS_2_ = los_D_OR_Better
        MAX_INDEX_LINES_71_ = maxInputFeaturesLines
        MAX_INDEX_LINES_72_ = maxInputFeaturesLines
        Headways_30_2_ = headways_30min_Or_Less
        MAX_INDEX_LINES_73_ = maxInputFeaturesLines
        MAX_INDEX_LINES_74_ = maxInputFeaturesLines
        Bike_Lanes_2_ = bikeLanes

        # Process: Select Layer By Location (Select Layer By Location) (management)
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            MAX_INDEX_LINES_2_, Output_Layer_Names, Count = arcpy.management.SelectLayerByLocation(in_layer=[MAX_INDEX_LINES], overlap_type="INTERSECT", select_features=Bike_Lanes, search_distance="", selection_type="NEW_SELECTION", invert_spatial_relationship="NOT_INVERT")

        # Process: Calculate Field (Calculate Field) (management)
        if MAX_INDEX_LINES_2_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_3_ = arcpy.management.CalculateField(in_table=MAX_INDEX_LINES_2_, field="BL_MAX", expression="3", expression_type="PYTHON3", code_block="", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Select Layer By Location (2) (Select Layer By Location) (management)
        if MAX_INDEX_LINES_2_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_4_, Output_Layer_Names_2_, Count_2_ = arcpy.management.SelectLayerByLocation(in_layer=[MAX_INDEX_LINES_3_], overlap_type="INTERSECT", select_features=Bike_Lanes, search_distance="1320 Feet", selection_type="NEW_SELECTION", invert_spatial_relationship="NOT_INVERT")

        # Process: Calculate Field (2) (Calculate Field) (management)
        if MAX_INDEX_LINES_2_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_5_ = arcpy.management.CalculateField(in_table=MAX_INDEX_LINES_4_, field="BL_QTR", expression="calc_field(!BL_MAX!,!BL_QTR!)", expression_type="PYTHON3", code_block="""def calc_field(BL_MAX, BL_QTR):
    if BL_MAX == 0:
        return 1.5
    else: 
        return 0""", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Select Layer By Location (3) (Select Layer By Location) (management)
        if MAX_INDEX_LINES_2_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_6_, Output_Layer_Names_3_, Count_3_ = arcpy.management.SelectLayerByLocation(in_layer=[MAX_INDEX_LINES_5_], overlap_type="INTERSECT", select_features=Bike_Lanes, search_distance="2640 Feet", selection_type="NEW_SELECTION", invert_spatial_relationship="NOT_INVERT")

        # Process: Calculate Field (3) (Calculate Field) (management)
        if MAX_INDEX_LINES_2_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_7_ = arcpy.management.CalculateField(in_table=MAX_INDEX_LINES_6_, field="BL_HLF", expression="calc_field(!BL_MAX!,!BL_QTR!,!BL_HLF!)", expression_type="PYTHON3", code_block="""def calc_field(BL_MAX, BL_QTR, BL_TOT):
    if BL_MAX == 0 and BL_QTR == 0:
        return 0.75
    else: 
        return 0""", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Calculate Field (4) (Calculate Field) (management)
        if MAX_INDEX_LINES_2_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_8_ = arcpy.management.CalculateField(in_table=MAX_INDEX_LINES_7_, field="BL_TOT", expression="!BL_MAX! + !BL_QTR! + !BL_HLF!", expression_type="PYTHON3", code_block="", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Select Layer By Location (4) (Select Layer By Location) (management)
        if MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_9_, Output_Layer_Names_4_, Count_4_ = arcpy.management.SelectLayerByLocation(in_layer=[MAX_INDEX_LINES_10_], overlap_type="INTERSECT", select_features=Headways_30, search_distance="", selection_type="NEW_SELECTION", invert_spatial_relationship="NOT_INVERT")

        # Process: Calculate Field (5) (Calculate Field) (management)
        if MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_11_ = arcpy.management.CalculateField(in_table=MAX_INDEX_LINES_9_, field="HW_MAX", expression="3", expression_type="PYTHON3", code_block="", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Select Layer By Location (5) (Select Layer By Location) (management)
        if MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_12_, Output_Layer_Names_5_, Count_5_ = arcpy.management.SelectLayerByLocation(in_layer=[MAX_INDEX_LINES_11_], overlap_type="INTERSECT", select_features=Headways_30, search_distance="1320 Feet", selection_type="NEW_SELECTION", invert_spatial_relationship="NOT_INVERT")

        # Process: Calculate Field (6) (Calculate Field) (management)
        if MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_15_ = arcpy.management.CalculateField(in_table=MAX_INDEX_LINES_12_, field="HW_QTR", expression="calc_field(!HW_MAX!,!HW_QTR!)", expression_type="PYTHON3", code_block="""def calc_field(HW_MAX, HW_QTR):
    if HW_MAX == 0:
        return 1.5
    else: 
        return 0""", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Select Layer By Location (6) (Select Layer By Location) (management)
        if MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_14_, Output_Layer_Names_6_, Count_6_ = arcpy.management.SelectLayerByLocation(in_layer=[MAX_INDEX_LINES_15_], overlap_type="INTERSECT", select_features=Headways_30, search_distance="2640 Feet", selection_type="NEW_SELECTION", invert_spatial_relationship="NOT_INVERT")

        # Process: Calculate Field (7) (Calculate Field) (management)
        if MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_13_ = arcpy.management.CalculateField(in_table=MAX_INDEX_LINES_14_, field="HW_HLF", expression="calc_field(!HW_MAX!,!HW_QTR!,!HW_HLF!)", expression_type="PYTHON3", code_block="""def calc_field(HW_MAX, HW_QTR, HW_HLF):
    if HW_MAX == 0 and HW_QTR == 0:
        return 0.75
    else: 
        return 0""", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Calculate Field (12) (Calculate Field) (management)
        if MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_21_ = arcpy.management.CalculateField(in_table=MAX_INDEX_LINES_13_, field="HW_TOT", expression="!HW_MAX! + !HW_QTR! + !HW_HLF!", expression_type="PYTHON3", code_block="", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Select Layer By Location (7) (Select Layer By Location) (management)
        if MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_17_, Output_Layer_Names_7_, Count_7_ = arcpy.management.SelectLayerByLocation(in_layer=[MAX_INDEX_LINES_18_], overlap_type="INTERSECT", select_features=LOS, search_distance="", selection_type="NEW_SELECTION", invert_spatial_relationship="NOT_INVERT")

        # Process: Calculate Field (8) (Calculate Field) (management)
        if MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_16_ = arcpy.management.CalculateField(in_table=MAX_INDEX_LINES_17_, field="LOS_MAX", expression="1.5", expression_type="PYTHON3", code_block="", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Select Layer By Location (8) (Select Layer By Location) (management)
        if MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_19_, Output_Layer_Names_8_, Count_8_ = arcpy.management.SelectLayerByLocation(in_layer=[MAX_INDEX_LINES_16_], overlap_type="INTERSECT", select_features=LOS, search_distance="1320 Feet", selection_type="NEW_SELECTION", invert_spatial_relationship="NOT_INVERT")

        # Process: Calculate Field (9) (Calculate Field) (management)
        if MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_25_ = arcpy.management.CalculateField(in_table=MAX_INDEX_LINES_19_, field="LOS_QTR", expression="calc_field(!LOS_MAX!,!LOS_QTR!)", expression_type="PYTHON3", code_block="""def calc_field(LOS_MAX, LOS_QTR):
    if LOS_MAX == 0:
        return 0.75
    else: 
        return 0""", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Select Layer By Location (9) (Select Layer By Location) (management)
        if MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_22_, Output_Layer_Names_9_, Count_9_ = arcpy.management.SelectLayerByLocation(in_layer=[MAX_INDEX_LINES_25_], overlap_type="INTERSECT", select_features=LOS, search_distance="2640 Feet", selection_type="NEW_SELECTION", invert_spatial_relationship="NOT_INVERT")

        # Process: Calculate Field (10) (Calculate Field) (management)
        if MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_20_ = arcpy.management.CalculateField(in_table=MAX_INDEX_LINES_22_, field="LOS_HLF", expression="calc_field(!LOS_MAX!,!LOS_QTR!,!LOS_HLF!)", expression_type="PYTHON3", code_block="""def calc_field(LOS_MAX, LOS_QTR, LOS_HLF):
    if LOS_MAX == 0 and LOS_QTR == 0:
        return 0.375
    else: 
        return 0""", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Calculate Field (11) (Calculate Field) (management)
        if MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_23_ = arcpy.management.CalculateField(in_table=MAX_INDEX_LINES_20_, field="LOS_TOT", expression="!LOS_MAX! + !LOS_QTR! + !LOS_HLF!", expression_type="PYTHON3", code_block="", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Select Layer By Location (22) (Select Layer By Location) (management)
        if MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_61_, Output_Layer_Names_22_, Count_23_ = arcpy.management.SelectLayerByLocation(in_layer=[MAX_INDEX_LINES_58_], overlap_type="INTERSECT", select_features=VC_RATIO_2_, search_distance="", selection_type="NEW_SELECTION", invert_spatial_relationship="NOT_INVERT")

        # Process: Calculate Field (30) (Calculate Field) (management)
        if MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_26_ = arcpy.management.CalculateField(in_table=MAX_INDEX_LINES_28_, field="VC_MAX", expression="1.5", expression_type="PYTHON3", code_block="", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Select Layer By Location (23) (Select Layer By Location) (management)
        if MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_63_, Output_Layer_Names_23_, Count_24_ = arcpy.management.SelectLayerByLocation(in_layer=[MAX_INDEX_LINES_26_], overlap_type="INTERSECT", select_features=VC_RATIO_2_, search_distance="1320 Feet", selection_type="NEW_SELECTION", invert_spatial_relationship="NOT_INVERT")

        # Process: Calculate Field (31) (Calculate Field) (management)
        if MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_27_ = arcpy.management.CalculateField(in_table=MAX_INDEX_LINES_64_, field="VC_QTR", expression="calc_field(!VC_MAX!,!VC_QTR!)", expression_type="PYTHON3", code_block="""def calc_field(VC_MAX, VC_QTR):
    if VC_MAX == 0:
        return 0.75
    else: 
        return 0""", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Select Layer By Location (24) (Select Layer By Location) (management)
        if MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_65_, Output_Layer_Names_24_, Count_25_ = arcpy.management.SelectLayerByLocation(in_layer=[MAX_INDEX_LINES_27_], overlap_type="INTERSECT", select_features=VC_RATIO_2_, search_distance="2640 Feet", selection_type="NEW_SELECTION", invert_spatial_relationship="NOT_INVERT")

        # Process: Calculate Field (32) (Calculate Field) (management)
        if MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_24_ = arcpy.management.CalculateField(in_table=MAX_INDEX_LINES_65_, field="VC_HLF", expression="calc_field(!VC_MAX!,!VC_QTR!,!VC_HLF!)", expression_type="PYTHON3", code_block="""def calc_field(VC_MAX, VC_QTR, VC_HLF):
    if VC_MAX == 0 and VC_QTR == 0:
        return 0.375
    else: 
        return 0""", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Calculate Field (33) (Calculate Field) (management)
        if MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_66_ = arcpy.management.CalculateField(in_table=MAX_INDEX_LINES_24_, field="VC_TOT", expression="!VC_MAX! + !VC_QTR! + !VC_HLF!", expression_type="PYTHON3", code_block="", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Select Layer By Location (13) (Select Layer By Location) (management)
        if MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_33_, Output_Layer_Names_13_, Count_13_ = arcpy.management.SelectLayerByLocation(in_layer=[MAX_INDEX_LINES_32_], overlap_type="INTERSECT", select_features=TIP_LINES, search_distance="", selection_type="NEW_SELECTION", invert_spatial_relationship="NOT_INVERT")

        # Process: Calculate Field (17) (Calculate Field) (management)
        if MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_41_ = arcpy.management.CalculateField(in_table=MAX_INDEX_LINES_33_, field="TIPL_MAX", expression="1", expression_type="PYTHON3", code_block="", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Select Layer By Location (14) (Select Layer By Location) (management)
        if MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_36_, Output_Layer_Names_14_, Count_14_ = arcpy.management.SelectLayerByLocation(in_layer=[MAX_INDEX_LINES_41_], overlap_type="INTERSECT", select_features=TIP_LINES, search_distance="1320 Feet", selection_type="NEW_SELECTION", invert_spatial_relationship="NOT_INVERT")

        # Process: Calculate Field (18) (Calculate Field) (management)
        if MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_34_ = arcpy.management.CalculateField(in_table=MAX_INDEX_LINES_36_, field="TIPL_QTR", expression="calc_field(!TIPL_MAX!,!TIPL_QTR!)", expression_type="PYTHON3", code_block="""def calc_field(TIPL_MAX, TIPL_QTR):
    if TIPL_MAX == 0:
        return 0.5
    else: 
        return 0""", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Select Layer By Location (15) (Select Layer By Location) (management)
        if MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_38_, Output_Layer_Names_15_, Count_15_ = arcpy.management.SelectLayerByLocation(in_layer=[MAX_INDEX_LINES_34_], overlap_type="INTERSECT", select_features=TIP_LINES, search_distance="2640 Feet", selection_type="NEW_SELECTION", invert_spatial_relationship="NOT_INVERT")

        # Process: Calculate Field (19) (Calculate Field) (management)
        if MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_48_ = arcpy.management.CalculateField(in_table=MAX_INDEX_LINES_38_, field="TIPL_HLF", expression="calc_field(!TIPL_MAX!,!TIPL_QTR!,!TIPL_HLF!)", expression_type="PYTHON3", code_block="""def calc_field(TIPL_MAX, TIPL_QTR, TIPL_HLF):
    if TIPL_MAX == 0 and TIPL_QTR == 0:
        return 0.25
    else: 
        return 0""", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Calculate Field (20) (Calculate Field) (management)
        if MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_39_ = arcpy.management.CalculateField(in_table=MAX_INDEX_LINES_48_, field="TIPL_TOT", expression="!TIPL_MAX! + !TIPL_QTR! + !TIPL_HLF!", expression_type="PYTHON3", code_block="", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Select Layer By Location (16) (Select Layer By Location) (management)
        if MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_42_, Output_Layer_Names_16_, Count_16_ = arcpy.management.SelectLayerByLocation(in_layer=[MAX_INDEX_LINES_40_], overlap_type="INTERSECT", select_features=TRAILS, search_distance="", selection_type="NEW_SELECTION", invert_spatial_relationship="NOT_INVERT")

        # Process: Calculate Field (21) (Calculate Field) (management)
        if MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_49_ = arcpy.management.CalculateField(in_table=MAX_INDEX_LINES_42_, field="TRL_MAX", expression="3", expression_type="PYTHON3", code_block="", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Select Layer By Location (17) (Select Layer By Location) (management)
        if MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_44_, Output_Layer_Names_17_, Count_17_ = arcpy.management.SelectLayerByLocation(in_layer=[MAX_INDEX_LINES_49_], overlap_type="INTERSECT", select_features=TRAILS, search_distance="1320 Feet", selection_type="NEW_SELECTION", invert_spatial_relationship="NOT_INVERT")

        # Process: Calculate Field (22) (Calculate Field) (management)
        if MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_30_ = arcpy.management.CalculateField(in_table=MAX_INDEX_LINES_44_, field="TRL_QTR", expression="calc_field(!TRL_MAX!,!TRL_QTR!)", expression_type="PYTHON3", code_block="""def calc_field(TRL_MAX, TRL_QTR):
    if TRL_MAX == 0:
        return 1.5
    else: 
        return 0""", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Select Layer By Location (18) (Select Layer By Location) (management)
        if MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_46_, Output_Layer_Names_18_, Count_18_ = arcpy.management.SelectLayerByLocation(in_layer=[MAX_INDEX_LINES_30_], overlap_type="INTERSECT", select_features=TRAILS, search_distance="2640 Feet", selection_type="NEW_SELECTION", invert_spatial_relationship="NOT_INVERT")

        # Process: Calculate Field (23) (Calculate Field) (management)
        if MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_45_ = arcpy.management.CalculateField(in_table=MAX_INDEX_LINES_46_, field="TRL_HLF", expression="calc_field(!TRL_MAX!,!TRL_QTR!,!TRL_HLF!)", expression_type="PYTHON3", code_block="""def calc_field(TRL_MAX, TRL_QTR, TRL_HLF):
    if TRL_MAX == 0 and TRL_QTR == 0:
        return 0.75
    else: 
        return 0""", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Calculate Field (24) (Calculate Field) (management)
        if MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_47_ = arcpy.management.CalculateField(in_table=MAX_INDEX_LINES_45_, field="TRL_TOT", expression="!TRL_MAX! + !TRL_QTR! + !TRL_HLF!", expression_type="PYTHON3", code_block="", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Select Layer By Location (19) (Select Layer By Location) (management)
        if MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_50_, Output_Layer_Names_19_, Count_19_ = arcpy.management.SelectLayerByLocation(in_layer=[MAX_INDEX_LINES_43_], overlap_type="INTERSECT", select_features=Sharrows, search_distance="", selection_type="NEW_SELECTION", invert_spatial_relationship="NOT_INVERT")

        # Process: Calculate Field (25) (Calculate Field) (management)
        if MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_50_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_59_ = arcpy.management.CalculateField(in_table=MAX_INDEX_LINES_57_, field="SHR_MAX", expression="1", expression_type="PYTHON3", code_block="", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Select Layer By Location (20) (Select Layer By Location) (management)
        if MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_50_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_52_, Output_Layer_Names_20_, Count_20_ = arcpy.management.SelectLayerByLocation(in_layer=[MAX_INDEX_LINES_59_], overlap_type="INTERSECT", select_features=Sharrows, search_distance="1320 Feet", selection_type="NEW_SELECTION", invert_spatial_relationship="NOT_INVERT")

        # Process: Calculate Field (26) (Calculate Field) (management)
        if MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_50_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_51_ = arcpy.management.CalculateField(in_table=MAX_INDEX_LINES_52_, field="SHR_QTR", expression="calc_field(!SHR_MAX!,!SHR_QTR!)", expression_type="PYTHON3", code_block="""def calc_field(SHR_MAX, SHR_QTR):
    if SHR_MAX == 0:
        return 0.5
    else: 
        return 0""", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Select Layer By Location (21) (Select Layer By Location) (management)
        if MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_50_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_54_, Output_Layer_Names_21_, Count_21_ = arcpy.management.SelectLayerByLocation(in_layer=[MAX_INDEX_LINES_51_], overlap_type="INTERSECT", select_features=Sharrows, search_distance="2640 Feet", selection_type="NEW_SELECTION", invert_spatial_relationship="NOT_INVERT")

        # Process: Calculate Field (27) (Calculate Field) (management)
        if MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_50_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_53_ = arcpy.management.CalculateField(in_table=MAX_INDEX_LINES_54_, field="SHR_HLF", expression="calc_field(!SHR_MAX!,!SHR_QTR!,!SHR_HLF!)", expression_type="PYTHON3", code_block="""def calc_field(SHR_MAX, SHR_QTR, SHR_HLF):
    if SHR_MAX == 0 and SHR_QTR == 0:
        return 0.25
    else: 
        return 0""", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Calculate Field (28) (Calculate Field) (management)
        if MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_50_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_55_ = arcpy.management.CalculateField(in_table=MAX_INDEX_LINES_53_, field="SHR_TOT", expression="!SHR_MAX! + !SHR_QTR! + !SHR_HLF!", expression_type="PYTHON3", code_block="", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Select Layer By Attribute (Select Layer By Attribute) (management)
        if MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_50_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_:
            with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
                MAX_INDEX_LINES_56_, Count_22_ = arcpy.management.SelectLayerByAttribute(in_layer_or_view=MAX_INDEX_LINES_55_, selection_type="CLEAR_SELECTION", where_clause="", invert_where_clause="")

        # Process: Spatial Join (Spatial Join) (analysis)
        BL_JOIN = f"{Workspace}\\BL_JOIN"
        if MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_50_ and MAX_INDEX_LINES_56_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_:
            arcpy.analysis.SpatialJoin(target_features=MAX_INDEX_LINES_74_, join_features=Bike_Lanes_2_, out_feature_class=BL_JOIN, join_operation="JOIN_ONE_TO_ONE", join_type="KEEP_ALL", field_mapping="Shape_Length \"Shape_Length\" false true true 8 Double 0 0,First,#,MAX_INDEX_LINES,Shape_Length,-1,-1;Shape_Area \"Shape_Area\" false true true 8 Double 0 0,First,#,MAX_INDEX_LINES,Shape_Area,-1,-1;BL_MAX \"BL_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,BL_MAX,-1,-1;BL_QTR \"BL_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,BL_QTR,-1,-1;BL_HLF \"BL_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,BL_HLF,-1,-1;BL_TOT \"BL_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,BL_TOT,-1,-1;HW_MAX \"HW_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,HW_MAX,-1,-1;HW_QTR \"HW_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,HW_QTR,-1,-1;HW_HLF \"HW_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,HW_HLF,-1,-1;HW_TOT \"HW_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,HW_TOT,-1,-1;LOS_MAX \"LOS_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,LOS_MAX,-1,-1;LOS_QTR \"LOS_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,LOS_QTR,-1,-1;LOS_HLF \"LOS_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,LOS_HLF,-1,-1;LOS_TOT \"LOS_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,LOS_TOT,-1,-1;VC_MAX \"VC_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,VC_MAX,-1,-1;VC_QTR \"VC_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,VC_QTR,-1,-1;VC_HLF \"VC_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,VC_HLF,-1,-1;VC_TOT \"VC_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,VC_TOT,-1,-1;TIPL_MAX \"TIPL_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TIPL_MAX,-1,-1;TIPL_QTR \"TIPL_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TIPL_QTR,-1,-1;TIPL_HLF \"TIPL_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TIPL_HLF,-1,-1;TIPL_TOT \"TIPL_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TIPL_TOT,-1,-1;TRL_MAX \"TRL_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TRL_MAX,-1,-1;TRL_QTR \"TRL_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TRL_QTR,-1,-1;TRL_HLF \"TRL_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TRL_HLF,-1,-1;TRL_TOT \"TRL_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TRL_TOT,-1,-1;SHR_MAX \"SHR_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,SHR_MAX,-1,-1;SHR_QTR \"SHR_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,SHR_QTR,-1,-1;SHR_HLF \"SHR_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,SHR_HLF,-1,-1;SHR_TOT \"SHR_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,SHR_TOT,-1,-1;TOT_LIN \"TOT_LIN\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TOT_LIN,-1,-1;FACILITYID \"Facility Identifier\" true true false 50 Text 0 0,First,#,Bike_Lanes,FACILITYID,0,50;NAME \"Trail Name\" true true false 255 Text 0 0,First,#,Bike_Lanes,NAME,0,255;LENGTH \"Length/Miles\" true true false 8 Double 0 0,First,#,Bike_Lanes,LENGTH,-1,-1;OWNEDBY \"Owned By\" true true false 2 Short 0 0,First,#,Bike_Lanes,OWNEDBY,-1,-1;MAINTBY \"Managed By\" true true false 2 Short 0 0,First,#,Bike_Lanes,MAINTBY,-1,-1;COMMENTS \"Comments\" true true false 255 Text 0 0,First,#,Bike_Lanes,COMMENTS,0,255;TRAILTYPE \"Trail Type\" true true false 50 Text 0 0,First,#,Bike_Lanes,TRAILTYPE,0,50;STATUS \"Status\" true true false 50 Text 0 0,First,#,Bike_Lanes,STATUS,0,50;RESPONSIBLEAGENCY \"Responsible Agency\" true true false 255 Text 0 0,First,#,Bike_Lanes,RESPONSIBLEAGENCY,0,255;JURISDICTION \"Jurisdiction\" true true false 255 Text 0 0,First,#,Bike_Lanes,JURISDICTION,0,255;APPROXCOST \"Approximate Cost\" true true false 4 Long 0 0,First,#,Bike_Lanes,APPROXCOST,-1,-1;FUNDINGSOURCE \"Funding Source\" true true false 30 Text 0 0,First,#,Bike_Lanes,FUNDINGSOURCE,0,30;FISCALYEAR \"Fiscal Year\" true true false 11 Text 0 0,First,#,Bike_Lanes,FISCALYEAR,0,11;CATEGORY \"Category\" true true false 40 Text 0 0,First,#,Bike_Lanes,CATEGORY,0,40;DESIGNATED \"Designated\" true true false 1 Text 0 0,First,#,Bike_Lanes,DESIGNATED,0,1;FUNDED \"Funded\" true true false 1 Text 0 0,First,#,Bike_Lanes,FUNDED,0,1;THELOOP \"Part of the Loop?\" true true false 1 Text 0 0,First,#,Bike_Lanes,THELOOP,0,1;AREAID1 \"Area ID 1\" true true false 2 Short 0 0,First,#,Bike_Lanes,AREAID1,-1,-1;AREAID2 \"Area ID 2\" true true false 2 Short 0 0,First,#,Bike_Lanes,AREAID2,-1,-1;AREAID3 \"Area ID 3\" true true false 2 Short 0 0,First,#,Bike_Lanes,AREAID3,-1,-1;CREATED_USER \"CREATED_USER\" true true false 255 Text 0 0,First,#,Bike_Lanes,CREATED_USER,0,255;CREATED_DATE \"CREATED_DATE\" true true false 8 Date 0 0,First,#,Bike_Lanes,CREATED_DATE,-1,-1;LAST_EDITED_USER \"LAST_EDITED_USER\" true true false 255 Text 0 0,First,#,Bike_Lanes,LAST_EDITED_USER,0,255;LAST_EDITED_DATE \"LAST_EDITED_DATE\" true true false 8 Date 0 0,First,#,Bike_Lanes,LAST_EDITED_DATE,-1,-1;ADOPTED \"ADOPTED\" true true false 8 Date 0 0,First,#,Bike_Lanes,ADOPTED,-1,-1;COMPLETED \"Completed Date\" true true false 8 Date 0 0,First,#,Bike_Lanes,COMPLETED,-1,-1;WIDTH \"Width/Feet\" true true false 15 Text 0 0,First,#,Bike_Lanes,WIDTH,0,15;Shape_Length_1 \"Shape_Length\" false true true 8 Double 0 0,First,#,Bike_Lanes,Shape_Length,-1,-1", match_option="INTERSECT", search_radius="", distance_field_name="")

        # Process: Add Join (Add Join) (management)
        if BL_JOIN and MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_50_ and MAX_INDEX_LINES_56_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_:
            MAX_INDEX_LINES_75_ = arcpy.management.AddJoin(in_layer_or_view=MAX_INDEX_LINES_73_, in_field="OBJECTID", join_table=BL_JOIN, join_field="OBJECTID", join_type="KEEP_ALL", index_join_fields="NO_INDEX_JOIN_FIELDS")[0]

        # Process: Calculate Field (13) (Calculate Field) (management)
        if BL_JOIN and MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_50_ and MAX_INDEX_LINES_56_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_:
            MAX_INDEX_LINES_76_ = arcpy.management.CalculateField(in_table=MAX_INDEX_LINES_75_, field="MAX_INDEX_LINES.BL_TOT", expression="calc_field(!MAX_INDEX_LINES.BL_TOT!,!BL_JOIN.Join_Count!)", expression_type="PYTHON3", code_block="""def calc_field(BL_TOT, JOIN_COUNT):
    if JOIN_COUNT == 0:
        return(1 * BL_TOT)
    else:
        return(BL_TOT * JOIN_COUNT)""", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Remove Join (Remove Join) (management)
        if BL_JOIN and MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_50_ and MAX_INDEX_LINES_56_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_:
            Layer_With_Join_Removed = arcpy.management.RemoveJoin(in_layer_or_view=MAX_INDEX_LINES_76_, join_name="BL_JOIN")[0]

        # Process: Spatial Join (2) (Spatial Join) (analysis)
        HW_JOIN = f"{Workspace}\\HW_JOIN"
        if BL_JOIN and Layer_With_Join_Removed and MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_50_ and MAX_INDEX_LINES_56_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_:
            arcpy.analysis.SpatialJoin(target_features=MAX_INDEX_LINES_72_, join_features=Headways_30_2_, out_feature_class=HW_JOIN, join_operation="JOIN_ONE_TO_ONE", join_type="KEEP_ALL", field_mapping="Shape_Length \"Shape_Length\" false true true 8 Double 0 0,First,#,MAX_INDEX_LINES,Shape_Length,-1,-1;Shape_Area \"Shape_Area\" false true true 8 Double 0 0,First,#,MAX_INDEX_LINES,Shape_Area,-1,-1;BL_MAX \"BL_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,BL_MAX,-1,-1;BL_QTR \"BL_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,BL_QTR,-1,-1;BL_HLF \"BL_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,BL_HLF,-1,-1;BL_TOT \"BL_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,BL_TOT,-1,-1;HW_MAX \"HW_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,HW_MAX,-1,-1;HW_QTR \"HW_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,HW_QTR,-1,-1;HW_HLF \"HW_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,HW_HLF,-1,-1;HW_TOT \"HW_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,HW_TOT,-1,-1;LOS_MAX \"LOS_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,LOS_MAX,-1,-1;LOS_QTR \"LOS_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,LOS_QTR,-1,-1;LOS_HLF \"LOS_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,LOS_HLF,-1,-1;LOS_TOT \"LOS_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,LOS_TOT,-1,-1;VC_MAX \"VC_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,VC_MAX,-1,-1;VC_QTR \"VC_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,VC_QTR,-1,-1;VC_HLF \"VC_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,VC_HLF,-1,-1;VC_TOT \"VC_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,VC_TOT,-1,-1;TIPL_MAX \"TIPL_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TIPL_MAX,-1,-1;TIPL_QTR \"TIPL_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TIPL_QTR,-1,-1;TIPL_HLF \"TIPL_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TIPL_HLF,-1,-1;TIPL_TOT \"TIPL_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TIPL_TOT,-1,-1;TRL_MAX \"TRL_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TRL_MAX,-1,-1;TRL_QTR \"TRL_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TRL_QTR,-1,-1;TRL_HLF \"TRL_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TRL_HLF,-1,-1;TRL_TOT \"TRL_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TRL_TOT,-1,-1;SHR_MAX \"SHR_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,SHR_MAX,-1,-1;SHR_QTR \"SHR_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,SHR_QTR,-1,-1;SHR_HLF \"SHR_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,SHR_HLF,-1,-1;SHR_TOT \"SHR_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,SHR_TOT,-1,-1;TOT_LIN \"TOT_LIN\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TOT_LIN,-1,-1;OBJECTID \"OBJECTID\" true true false 4 Long 0 0,First,#,Headways_30,OBJECTID,-1,-1;VAR_ROUTE \"VAR_ROUTE\" true true false 6 Text 0 0,First,#,Headways_30,VAR_ROUTE,0,6;VAR_IDENT \"VAR_IDENT\" true true false 9 Text 0 0,First,#,Headways_30,VAR_IDENT,0,9;VAR_DIREC \"VAR_DIREC\" true true false 8 Double 0 0,First,#,Headways_30,VAR_DIREC,-1,-1;VAR_DESCR \"VAR_DESCR\" true true false 61 Text 0 0,First,#,Headways_30,VAR_DESCR,0,61;Service_Ty \"Service_Ty\" true true false 50 Text 0 0,First,#,Headways_30,Service_Ty,0,50;Shape_Leng \"Shape_Leng\" true true false 8 Double 0 0,First,#,Headways_30,Shape_Leng,-1,-1;Shape_Length_1 \"Shape_Length\" false true true 8 Double 0 0,First,#,Headways_30,Shape_Length,-1,-1", match_option="INTERSECT", search_radius="", distance_field_name="")

        # Process: Add Join (2) (Add Join) (management)
        if BL_JOIN and HW_JOIN and Layer_With_Join_Removed and MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_50_ and MAX_INDEX_LINES_56_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_:
            MAX_INDEX_LINES_77_ = arcpy.management.AddJoin(in_layer_or_view=MAX_INDEX_LINES_71_, in_field="OBJECTID", join_table=HW_JOIN, join_field="OBJECTID", join_type="KEEP_ALL", index_join_fields="NO_INDEX_JOIN_FIELDS")[0]

        # Process: Calculate Field (14) (Calculate Field) (management)
        if BL_JOIN and HW_JOIN and Layer_With_Join_Removed and MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_50_ and MAX_INDEX_LINES_56_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_:
            MAX_INDEX_LINES_78_ = arcpy.management.CalculateField(in_table=MAX_INDEX_LINES_77_, field="MAX_INDEX_LINES.HW_TOT", expression="calc_field(!MAX_INDEX_LINES.HW_TOT!,!HW_JOIN.Join_Count!)", expression_type="PYTHON3", code_block="""def calc_field(HW_TOT, JOIN_COUNT):
    if JOIN_COUNT == 0:
        return(1 * HW_TOT)
    else:
        return(HW_TOT * JOIN_COUNT)""", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Remove Join (2) (Remove Join) (management)
        if BL_JOIN and HW_JOIN and Layer_With_Join_Removed and MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_50_ and MAX_INDEX_LINES_56_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_:
            Layer_With_Join_Removed_2_ = arcpy.management.RemoveJoin(in_layer_or_view=MAX_INDEX_LINES_78_, join_name="HW_JOIN")[0]

        # Process: Spatial Join (3) (Spatial Join) (analysis)
        LOS_JOIN = f"{Workspace}\\LOS_JOIN"
        if BL_JOIN and HW_JOIN and Layer_With_Join_Removed and Layer_With_Join_Removed_2_ and MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_50_ and MAX_INDEX_LINES_56_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_:
            arcpy.analysis.SpatialJoin(target_features=MAX_INDEX_LINES_70_, join_features=LOS_2_, out_feature_class=LOS_JOIN, join_operation="JOIN_ONE_TO_ONE", join_type="KEEP_ALL", field_mapping="Shape_Length \"Shape_Length\" false true true 8 Double 0 0,First,#,MAX_INDEX_LINES,Shape_Length,-1,-1;Shape_Area \"Shape_Area\" false true true 8 Double 0 0,First,#,MAX_INDEX_LINES,Shape_Area,-1,-1;BL_MAX \"BL_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,BL_MAX,-1,-1;BL_QTR \"BL_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,BL_QTR,-1,-1;BL_HLF \"BL_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,BL_HLF,-1,-1;BL_TOT \"BL_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,BL_TOT,-1,-1;HW_MAX \"HW_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,HW_MAX,-1,-1;HW_QTR \"HW_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,HW_QTR,-1,-1;HW_HLF \"HW_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,HW_HLF,-1,-1;HW_TOT \"HW_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,HW_TOT,-1,-1;LOS_MAX \"LOS_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,LOS_MAX,-1,-1;LOS_QTR \"LOS_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,LOS_QTR,-1,-1;LOS_HLF \"LOS_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,LOS_HLF,-1,-1;LOS_TOT \"LOS_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,LOS_TOT,-1,-1;VC_MAX \"VC_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,VC_MAX,-1,-1;VC_QTR \"VC_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,VC_QTR,-1,-1;VC_HLF \"VC_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,VC_HLF,-1,-1;VC_TOT \"VC_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,VC_TOT,-1,-1;TIPL_MAX \"TIPL_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TIPL_MAX,-1,-1;TIPL_QTR \"TIPL_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TIPL_QTR,-1,-1;TIPL_HLF \"TIPL_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TIPL_HLF,-1,-1;TIPL_TOT \"TIPL_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TIPL_TOT,-1,-1;TRL_MAX \"TRL_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TRL_MAX,-1,-1;TRL_QTR \"TRL_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TRL_QTR,-1,-1;TRL_HLF \"TRL_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TRL_HLF,-1,-1;TRL_TOT \"TRL_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TRL_TOT,-1,-1;SHR_MAX \"SHR_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,SHR_MAX,-1,-1;SHR_QTR \"SHR_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,SHR_QTR,-1,-1;SHR_HLF \"SHR_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,SHR_HLF,-1,-1;SHR_TOT \"SHR_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,SHR_TOT,-1,-1;TOT_LIN \"TOT_LIN\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TOT_LIN,-1,-1;DataID \"DataID\" true true false 50 Text 0 0,First,#,LOS,DataID,0,50;LENGTHFT \"LENGTHFT\" true true false 8 Double 0 0,First,#,LOS,LENGTHFT,-1,-1;ONSTREET \"ONSTREET\" true true false 50 Text 0 0,First,#,LOS,ONSTREET,0,50;FRSTREET \"FRSTREET\" true true false 50 Text 0 0,First,#,LOS,FRSTREET,0,50;TOSTREET \"TOSTREET\" true true false 50 Text 0 0,First,#,LOS,TOSTREET,0,50;SEG_RT \"SEG_RT\" true true false 50 Text 0 0,First,#,LOS,SEG_RT,0,50;SEG_AADT \"SEG_AADT\" true true false 50 Text 0 0,First,#,LOS,SEG_AADT,0,50;JURIS \"JURIS\" true true false 50 Text 0 0,First,#,LOS,JURIS,0,50;CSASSIGN \"CSASSIGN\" true true false 50 Text 0 0,First,#,LOS,CSASSIGN,0,50;PM_PK_DI \"PM_PK_DI\" true true false 8 Double 0 0,First,#,LOS,PM_PK_DI,-1,-1;SIGNALCT \"SIGNALCT\" true true false 8 Double 0 0,First,#,LOS,SIGNALCT,-1,-1;FAC_ID \"FAC_ID\" true true false 8 Double 0 0,First,#,LOS,FAC_ID,-1,-1;SPEED \"SPEED\" true true false 8 Double 0 0,First,#,LOS,SPEED,-1,-1;SEGMENTID \"SEGMENTID\" true true false 10 Text 0 0,First,#,LOS,SEGMENTID,0,10;CURRENTYEA \"CURRENTYEA\" true true false 4 Long 0 0,First,#,LOS,CURRENTYEA,-1,-1;ONSTREET_1 \"ONSTREET_1\" true true false 100 Text 0 0,First,#,LOS,ONSTREET_1,0,100;FROMSTREET \"FROMSTREET\" true true false 100 Text 0 0,First,#,LOS,FROMSTREET,0,100;TOSTREET_1 \"TOSTREET_1\" true true false 100 Text 0 0,First,#,LOS,TOSTREET_1,0,100;STATIONID \"STATIONID\" true true false 50 Text 0 0,First,#,LOS,STATIONID,0,50;LENGTH_MIL \"LENGTH_MIL\" true true false 30 Text 0 0,First,#,LOS,LENGTH_MIL,0,30;AREA_TYPE \"AREA_TYPE\" true true false 50 Text 0 0,First,#,LOS,AREA_TYPE,0,50;ROADWAY_TY \"ROADWAY_TY\" true true false 50 Text 0 0,First,#,LOS,ROADWAY_TY,0,50;JURISDICTI \"JURISDICTI\" true true false 50 Text 0 0,First,#,LOS,JURISDICTI,0,50;ROADWAY_CL \"ROADWAY_CL\" true true false 100 Text 0 0,First,#,LOS,ROADWAY_CL,0,100;MEDIAN_TYP \"MEDIAN_TYP\" true true false 50 Text 0 0,First,#,LOS,MEDIAN_TYP,0,50;RIGHTTURN_ \"RIGHTTURN_\" true true false 4 Long 0 0,First,#,LOS,RIGHTTURN_,-1,-1;RIGHTTURN1 \"RIGHTTURN1\" true true false 4 Long 0 0,First,#,LOS,RIGHTTURN1,-1,-1;LEFTTURN_L \"LEFTTURN_L\" true true false 4 Long 0 0,First,#,LOS,LEFTTURN_L,-1,-1;LEFTTURN_1 \"LEFTTURN_1\" true true false 4 Long 0 0,First,#,LOS,LEFTTURN_1,-1,-1;RTL_PRESEN \"RTL_PRESEN\" true true false 10 Text 0 0,First,#,LOS,RTL_PRESEN,0,10;LTL_PRESEN \"LTL_PRESEN\" true true false 10 Text 0 0,First,#,LOS,LTL_PRESEN,0,10;NUM_LANES \"NUM_LANES\" true true false 4 Long 0 0,First,#,LOS,NUM_LANES,-1,-1;NUM_SIGNAL \"NUM_SIGNAL\" true true false 4 Long 0 0,First,#,LOS,NUM_SIGNAL,-1,-1;SIGNALS_PE \"SIGNALS_PE\" true true false 30 Text 0 0,First,#,LOS,SIGNALS_PE,0,30;LOS_STANDA \"LOS_STANDA\" true true false 1 Text 0 0,First,#,LOS,LOS_STANDA,0,1;HIST_GROWT \"HIST_GROWT\" true true false 8 Double 0 0,First,#,LOS,HIST_GROWT,-1,-1;K100 \"K100\" true true false 30 Text 0 0,First,#,LOS,K100,0,30;AADT \"AADT\" true true false 8 Double 0 0,First,#,LOS,AADT,-1,-1;MAXSERV_VO \"MAXSERV_VO\" true true false 4 Long 0 0,First,#,LOS,MAXSERV_VO,-1,-1;AM_DFACTOR \"AM_DFACTOR\" true true false 30 Text 0 0,First,#,LOS,AM_DFACTOR,0,30;PM_DFACTOR \"PM_DFACTOR\" true true false 30 Text 0 0,First,#,LOS,PM_DFACTOR,0,30;AM_VOLUME \"AM_VOLUME\" true true false 4 Long 0 0,First,#,LOS,AM_VOLUME,-1,-1;PM_VOLUME \"PM_VOLUME\" true true false 4 Long 0 0,First,#,LOS,PM_VOLUME,-1,-1;AM_SEGMENT \"AM_SEGMENT\" true true false 7 Text 0 0,First,#,LOS,AM_SEGMENT,0,7;AM_SEGME_1 \"AM_SEGME_1\" true true false 30 Text 0 0,First,#,LOS,AM_SEGME_1,0,30;PM_SEGMENT \"PM_SEGMENT\" true true false 7 Text 0 0,First,#,LOS,PM_SEGMENT,0,7;PM_SEGME_1 \"PM_SEGME_1\" true true false 30 Text 0 0,First,#,LOS,PM_SEGME_1,0,30;VMT \"VMT\" true true false 8 Double 0 0,First,#,LOS,VMT,-1,-1;VMT_VC \"VMT_VC\" true true false 8 Double 0 0,First,#,LOS,VMT_VC,-1,-1;COND_VMT \"COND_VMT\" true true false 8 Double 0 0,First,#,LOS,COND_VMT,-1,-1;Peak_ \"Peak_\" true true false 8 Double 0 0,First,#,LOS,Peak_,-1,-1;Shape_Length_1 \"Shape_Length\" false true true 8 Double 0 0,First,#,LOS,Shape_Length,-1,-1", match_option="INTERSECT", search_radius="", distance_field_name="")

        # Process: Add Join (3) (Add Join) (management)
        if BL_JOIN and HW_JOIN and LOS_JOIN and Layer_With_Join_Removed and Layer_With_Join_Removed_2_ and MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_50_ and MAX_INDEX_LINES_56_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_:
            MAX_INDEX_LINES_79_ = arcpy.management.AddJoin(in_layer_or_view=MAX_INDEX_LINES_69_, in_field="OBJECTID", join_table=LOS_JOIN, join_field="OBJECTID", join_type="KEEP_ALL", index_join_fields="NO_INDEX_JOIN_FIELDS")[0]

        # Process: Calculate Field (15) (Calculate Field) (management)
        if BL_JOIN and HW_JOIN and LOS_JOIN and Layer_With_Join_Removed and Layer_With_Join_Removed_2_ and MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_50_ and MAX_INDEX_LINES_56_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_:
            MAX_INDEX_LINES_80_ = arcpy.management.CalculateField(in_table=MAX_INDEX_LINES_79_, field="MAX_INDEX_LINES.LOS_TOT", expression="""calc_field(!MAX_INDEX_LINES.LOS_TOT!,!LOS_JOIN.Join_Count!)
""", expression_type="PYTHON3", code_block="""def calc_field(LOS_TOT, JOIN_COUNT):
    if JOIN_COUNT == 0:
        return(1 * LOS_TOT)
    else:
        return(LOS_TOT * JOIN_COUNT)""", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Remove Join (3) (Remove Join) (management)
        if BL_JOIN and HW_JOIN and LOS_JOIN and Layer_With_Join_Removed and Layer_With_Join_Removed_2_ and MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_50_ and MAX_INDEX_LINES_56_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_:
            Layer_With_Join_Removed_3_ = arcpy.management.RemoveJoin(in_layer_or_view=MAX_INDEX_LINES_80_, join_name="LOS_JOIN")[0]

        # Process: Spatial Join (4) (Spatial Join) (analysis)
        VC_JOIN = f"{Workspace}\\VC_JOIN"
        if BL_JOIN and HW_JOIN and LOS_JOIN and Layer_With_Join_Removed and Layer_With_Join_Removed_2_ and Layer_With_Join_Removed_3_ and MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_50_ and MAX_INDEX_LINES_56_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_:
            arcpy.analysis.SpatialJoin(target_features=MAX_INDEX_LINES_68_, join_features=VC_RATIO, out_feature_class=VC_JOIN, join_operation="JOIN_ONE_TO_ONE", join_type="KEEP_ALL", field_mapping="Shape_Length \"Shape_Length\" false true true 8 Double 0 0,First,#,MAX_INDEX_LINES,Shape_Length,-1,-1;Shape_Area \"Shape_Area\" false true true 8 Double 0 0,First,#,MAX_INDEX_LINES,Shape_Area,-1,-1;BL_MAX \"BL_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,BL_MAX,-1,-1;BL_QTR \"BL_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,BL_QTR,-1,-1;BL_HLF \"BL_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,BL_HLF,-1,-1;BL_TOT \"BL_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,BL_TOT,-1,-1;HW_MAX \"HW_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,HW_MAX,-1,-1;HW_QTR \"HW_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,HW_QTR,-1,-1;HW_HLF \"HW_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,HW_HLF,-1,-1;HW_TOT \"HW_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,HW_TOT,-1,-1;LOS_MAX \"LOS_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,LOS_MAX,-1,-1;LOS_QTR \"LOS_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,LOS_QTR,-1,-1;LOS_HLF \"LOS_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,LOS_HLF,-1,-1;LOS_TOT \"LOS_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,LOS_TOT,-1,-1;VC_MAX \"VC_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,VC_MAX,-1,-1;VC_QTR \"VC_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,VC_QTR,-1,-1;VC_HLF \"VC_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,VC_HLF,-1,-1;VC_TOT \"VC_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,VC_TOT,-1,-1;TIPL_MAX \"TIPL_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TIPL_MAX,-1,-1;TIPL_QTR \"TIPL_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TIPL_QTR,-1,-1;TIPL_HLF \"TIPL_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TIPL_HLF,-1,-1;TIPL_TOT \"TIPL_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TIPL_TOT,-1,-1;TRL_MAX \"TRL_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TRL_MAX,-1,-1;TRL_QTR \"TRL_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TRL_QTR,-1,-1;TRL_HLF \"TRL_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TRL_HLF,-1,-1;TRL_TOT \"TRL_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TRL_TOT,-1,-1;SHR_MAX \"SHR_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,SHR_MAX,-1,-1;SHR_QTR \"SHR_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,SHR_QTR,-1,-1;SHR_HLF \"SHR_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,SHR_HLF,-1,-1;SHR_TOT \"SHR_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,SHR_TOT,-1,-1;TOT_LIN \"TOT_LIN\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TOT_LIN,-1,-1;DataID \"DataID\" true true false 50 Text 0 0,First,#,VC_RATIO,DataID,0,50;LENGTHFT \"LENGTHFT\" true true false 8 Double 0 0,First,#,VC_RATIO,LENGTHFT,-1,-1;ONSTREET \"ONSTREET\" true true false 50 Text 0 0,First,#,VC_RATIO,ONSTREET,0,50;FRSTREET \"FRSTREET\" true true false 50 Text 0 0,First,#,VC_RATIO,FRSTREET,0,50;TOSTREET \"TOSTREET\" true true false 50 Text 0 0,First,#,VC_RATIO,TOSTREET,0,50;SEG_RT \"SEG_RT\" true true false 50 Text 0 0,First,#,VC_RATIO,SEG_RT,0,50;SEG_AADT \"SEG_AADT\" true true false 50 Text 0 0,First,#,VC_RATIO,SEG_AADT,0,50;JURIS \"JURIS\" true true false 50 Text 0 0,First,#,VC_RATIO,JURIS,0,50;CSASSIGN \"CSASSIGN\" true true false 50 Text 0 0,First,#,VC_RATIO,CSASSIGN,0,50;PM_PK_DI \"PM_PK_DI\" true true false 8 Double 0 0,First,#,VC_RATIO,PM_PK_DI,-1,-1;SIGNALCT \"SIGNALCT\" true true false 8 Double 0 0,First,#,VC_RATIO,SIGNALCT,-1,-1;FAC_ID \"FAC_ID\" true true false 8 Double 0 0,First,#,VC_RATIO,FAC_ID,-1,-1;SPEED \"SPEED\" true true false 8 Double 0 0,First,#,VC_RATIO,SPEED,-1,-1;SEGMENTID \"SEGMENTID\" true true false 10 Text 0 0,First,#,VC_RATIO,SEGMENTID,0,10;CURRENTYEA \"CURRENTYEA\" true true false 4 Long 0 0,First,#,VC_RATIO,CURRENTYEA,-1,-1;ONSTREET_1 \"ONSTREET_1\" true true false 100 Text 0 0,First,#,VC_RATIO,ONSTREET_1,0,100;FROMSTREET \"FROMSTREET\" true true false 100 Text 0 0,First,#,VC_RATIO,FROMSTREET,0,100;TOSTREET_1 \"TOSTREET_1\" true true false 100 Text 0 0,First,#,VC_RATIO,TOSTREET_1,0,100;STATIONID \"STATIONID\" true true false 50 Text 0 0,First,#,VC_RATIO,STATIONID,0,50;LENGTH_MIL \"LENGTH_MIL\" true true false 30 Text 0 0,First,#,VC_RATIO,LENGTH_MIL,0,30;AREA_TYPE \"AREA_TYPE\" true true false 50 Text 0 0,First,#,VC_RATIO,AREA_TYPE,0,50;ROADWAY_TY \"ROADWAY_TY\" true true false 50 Text 0 0,First,#,VC_RATIO,ROADWAY_TY,0,50;JURISDICTI \"JURISDICTI\" true true false 50 Text 0 0,First,#,VC_RATIO,JURISDICTI,0,50;ROADWAY_CL \"ROADWAY_CL\" true true false 100 Text 0 0,First,#,VC_RATIO,ROADWAY_CL,0,100;MEDIAN_TYP \"MEDIAN_TYP\" true true false 50 Text 0 0,First,#,VC_RATIO,MEDIAN_TYP,0,50;RIGHTTURN_ \"RIGHTTURN_\" true true false 4 Long 0 0,First,#,VC_RATIO,RIGHTTURN_,-1,-1;RIGHTTURN1 \"RIGHTTURN1\" true true false 4 Long 0 0,First,#,VC_RATIO,RIGHTTURN1,-1,-1;LEFTTURN_L \"LEFTTURN_L\" true true false 4 Long 0 0,First,#,VC_RATIO,LEFTTURN_L,-1,-1;LEFTTURN_1 \"LEFTTURN_1\" true true false 4 Long 0 0,First,#,VC_RATIO,LEFTTURN_1,-1,-1;RTL_PRESEN \"RTL_PRESEN\" true true false 10 Text 0 0,First,#,VC_RATIO,RTL_PRESEN,0,10;LTL_PRESEN \"LTL_PRESEN\" true true false 10 Text 0 0,First,#,VC_RATIO,LTL_PRESEN,0,10;NUM_LANES \"NUM_LANES\" true true false 4 Long 0 0,First,#,VC_RATIO,NUM_LANES,-1,-1;NUM_SIGNAL \"NUM_SIGNAL\" true true false 4 Long 0 0,First,#,VC_RATIO,NUM_SIGNAL,-1,-1;SIGNALS_PE \"SIGNALS_PE\" true true false 30 Text 0 0,First,#,VC_RATIO,SIGNALS_PE,0,30;LOS_STANDA \"LOS_STANDA\" true true false 1 Text 0 0,First,#,VC_RATIO,LOS_STANDA,0,1;HIST_GROWT \"HIST_GROWT\" true true false 8 Double 0 0,First,#,VC_RATIO,HIST_GROWT,-1,-1;K100 \"K100\" true true false 30 Text 0 0,First,#,VC_RATIO,K100,0,30;AADT \"AADT\" true true false 8 Double 0 0,First,#,VC_RATIO,AADT,-1,-1;MAXSERV_VO \"MAXSERV_VO\" true true false 4 Long 0 0,First,#,VC_RATIO,MAXSERV_VO,-1,-1;AM_DFACTOR \"AM_DFACTOR\" true true false 30 Text 0 0,First,#,VC_RATIO,AM_DFACTOR,0,30;PM_DFACTOR \"PM_DFACTOR\" true true false 30 Text 0 0,First,#,VC_RATIO,PM_DFACTOR,0,30;AM_VOLUME \"AM_VOLUME\" true true false 4 Long 0 0,First,#,VC_RATIO,AM_VOLUME,-1,-1;PM_VOLUME \"PM_VOLUME\" true true false 4 Long 0 0,First,#,VC_RATIO,PM_VOLUME,-1,-1;AM_SEGMENT \"AM_SEGMENT\" true true false 7 Text 0 0,First,#,VC_RATIO,AM_SEGMENT,0,7;AM_SEGME_1 \"AM_SEGME_1\" true true false 30 Text 0 0,First,#,VC_RATIO,AM_SEGME_1,0,30;PM_SEGMENT \"PM_SEGMENT\" true true false 7 Text 0 0,First,#,VC_RATIO,PM_SEGMENT,0,7;PM_SEGME_1 \"PM_SEGME_1\" true true false 30 Text 0 0,First,#,VC_RATIO,PM_SEGME_1,0,30;VMT \"VMT\" true true false 8 Double 0 0,First,#,VC_RATIO,VMT,-1,-1;VMT_VC \"VMT_VC\" true true false 8 Double 0 0,First,#,VC_RATIO,VMT_VC,-1,-1;COND_VMT \"COND_VMT\" true true false 8 Double 0 0,First,#,VC_RATIO,COND_VMT,-1,-1;Peak_ \"Peak_\" true true false 8 Double 0 0,First,#,VC_RATIO,Peak_,-1,-1;Shape_Length_1 \"Shape_Length\" false true true 8 Double 0 0,First,#,VC_RATIO,Shape_Length,-1,-1", match_option="INTERSECT", search_radius="", distance_field_name="")

        # Process: Add Join (4) (Add Join) (management)
        if BL_JOIN and HW_JOIN and LOS_JOIN and Layer_With_Join_Removed and Layer_With_Join_Removed_2_ and Layer_With_Join_Removed_3_ and MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_50_ and MAX_INDEX_LINES_56_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_ and VC_JOIN:
            MAX_INDEX_LINES_81_ = arcpy.management.AddJoin(in_layer_or_view=MAX_INDEX_LINES_67_, in_field="OBJECTID", join_table=VC_JOIN, join_field="OBJECTID", join_type="KEEP_ALL", index_join_fields="NO_INDEX_JOIN_FIELDS")[0]

        # Process: Calculate Field (16) (Calculate Field) (management)
        if BL_JOIN and HW_JOIN and LOS_JOIN and Layer_With_Join_Removed and Layer_With_Join_Removed_2_ and Layer_With_Join_Removed_3_ and MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_50_ and MAX_INDEX_LINES_56_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_ and VC_JOIN:
            MAX_INDEX_LINES_82_ = arcpy.management.CalculateField(in_table=MAX_INDEX_LINES_81_, field="MAX_INDEX_LINES.VC_TOT", expression="calc_field(!MAX_INDEX_LINES.VC_TOT!,!VC_JOIN.Join_Count!)", expression_type="PYTHON3", code_block="""def calc_field(VC_TOT, JOIN_COUNT):
    if JOIN_COUNT == 0:
        return(1 * VC_TOT)
    else:
        return(VC_TOT * JOIN_COUNT)""", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Remove Join (4) (Remove Join) (management)
        if BL_JOIN and HW_JOIN and LOS_JOIN and Layer_With_Join_Removed and Layer_With_Join_Removed_2_ and Layer_With_Join_Removed_3_ and MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_50_ and MAX_INDEX_LINES_56_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_ and VC_JOIN:
            Layer_With_Join_Removed_4_ = arcpy.management.RemoveJoin(in_layer_or_view=MAX_INDEX_LINES_82_, join_name="VC_JOIN")[0]

        # Process: Spatial Join (5) (Spatial Join) (analysis)
        TIPL_JOIN = f"{Workspace}\\TIPL_JOIN"
        if BL_JOIN and HW_JOIN and LOS_JOIN and Layer_With_Join_Removed and Layer_With_Join_Removed_2_ and Layer_With_Join_Removed_3_ and Layer_With_Join_Removed_4_ and MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_50_ and MAX_INDEX_LINES_56_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_ and VC_JOIN:
            arcpy.analysis.SpatialJoin(target_features=MAX_INDEX_LINES_62_, join_features=TIP_LINES_2_, out_feature_class=TIPL_JOIN, join_operation="JOIN_ONE_TO_ONE", join_type="KEEP_ALL", field_mapping="Shape_Length \"Shape_Length\" false true true 8 Double 0 0,First,#,MAX_INDEX_LINES,Shape_Length,-1,-1;Shape_Area \"Shape_Area\" false true true 8 Double 0 0,First,#,MAX_INDEX_LINES,Shape_Area,-1,-1;BL_MAX \"BL_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,BL_MAX,-1,-1;BL_QTR \"BL_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,BL_QTR,-1,-1;BL_HLF \"BL_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,BL_HLF,-1,-1;BL_TOT \"BL_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,BL_TOT,-1,-1;HW_MAX \"HW_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,HW_MAX,-1,-1;HW_QTR \"HW_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,HW_QTR,-1,-1;HW_HLF \"HW_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,HW_HLF,-1,-1;HW_TOT \"HW_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,HW_TOT,-1,-1;LOS_MAX \"LOS_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,LOS_MAX,-1,-1;LOS_QTR \"LOS_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,LOS_QTR,-1,-1;LOS_HLF \"LOS_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,LOS_HLF,-1,-1;LOS_TOT \"LOS_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,LOS_TOT,-1,-1;VC_MAX \"VC_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,VC_MAX,-1,-1;VC_QTR \"VC_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,VC_QTR,-1,-1;VC_HLF \"VC_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,VC_HLF,-1,-1;VC_TOT \"VC_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,VC_TOT,-1,-1;TIPL_MAX \"TIPL_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TIPL_MAX,-1,-1;TIPL_QTR \"TIPL_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TIPL_QTR,-1,-1;TIPL_HLF \"TIPL_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TIPL_HLF,-1,-1;TIPL_TOT \"TIPL_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TIPL_TOT,-1,-1;TRL_MAX \"TRL_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TRL_MAX,-1,-1;TRL_QTR \"TRL_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TRL_QTR,-1,-1;TRL_HLF \"TRL_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TRL_HLF,-1,-1;TRL_TOT \"TRL_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TRL_TOT,-1,-1;SHR_MAX \"SHR_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,SHR_MAX,-1,-1;SHR_QTR \"SHR_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,SHR_QTR,-1,-1;SHR_HLF \"SHR_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,SHR_HLF,-1,-1;SHR_TOT \"SHR_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,SHR_TOT,-1,-1;TOT_LIN \"TOT_LIN\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TOT_LIN,-1,-1;PROJECT_ID \"PROJECT_ID\" true true false 255 Text 0 0,First,#,TIP_LINES,PROJECT_ID,0,255;PROJECT_NA \"PROJECT_NA\" true true false 255 Text 0 0,First,#,TIP_LINES,PROJECT_NA,0,255;PIC_URL \"PIC_URL\" true true false 255 Text 0 0,First,#,TIP_LINES,PIC_URL,0,255;WEBSITE \"WEBSITE\" true true false 8 Double 0 0,First,#,TIP_LINES,WEBSITE,-1,-1;TIPTYPE \"TIPTYPE\" true true false 50 Text 0 0,First,#,TIP_LINES,TIPTYPE,0,50;FWDPIN_NOTES \"NOTES\" true true false 255 Text 0 0,First,#,TIP_LINES,FWDPIN_NOTES,0,255;FWDPIN_ATTACH \"Attachment\" true true false 50 Text 0 0,First,#,TIP_LINES,FWDPIN_ATTACH,0,50;DISPLAY_YN \"DISPLAY Y or N\" true true false 5 Text 0 0,First,#,TIP_LINES,DISPLAY_YN,0,5;FWDPIN_YEAR \"FWD P PROGRAM YEAR\" true true false 2 Short 0 0,First,#,TIP_LINES,FWDPIN_YEAR,-1,-1;CREATED_USER \"CREATED_USER\" true true false 255 Text 0 0,First,#,TIP_LINES,CREATED_USER,0,255;CREATED_DATE \"CREATED_DATE\" true true false 8 Date 0 0,First,#,TIP_LINES,CREATED_DATE,-1,-1;LAST_EDITED_USER \"LAST_EDITED_USER\" true true false 255 Text 0 0,First,#,TIP_LINES,LAST_EDITED_USER,0,255;LAST_EDITED_DATE \"LAST_EDITED_DATE\" true true false 8 Date 0 0,First,#,TIP_LINES,LAST_EDITED_DATE,-1,-1;PROJECT_YEAR \"PROJECT_YEAR\" true true false 2 Short 0 0,First,#,TIP_LINES,PROJECT_YEAR,-1,-1;TYPE_OTHER \"TYPE_OTHER\" true true false 50 Text 0 0,First,#,TIP_LINES,TYPE_OTHER,0,50;PROJECT_STARTDATE \"Project Start Date\" true true false 8 Date 0 0,First,#,TIP_LINES,PROJECT_STARTDATE,-1,-1;PROJECTPHASE \"Project Phase\" true true false 255 Text 0 0,First,#,TIP_LINES,PROJECTPHASE,0,255;PROJECTPHASECOST \"Project Phase Cost\" true true false 255 Text 0 0,First,#,TIP_LINES,PROJECTPHASECOST,0,255;PROJECTTOTALCOST \"Project Total Cost\" true true false 255 Text 0 0,First,#,TIP_LINES,PROJECTTOTALCOST,0,255;DESCRIPTION \"Description\" true true false 255 Text 0 0,First,#,TIP_LINES,DESCRIPTION,0,255;COMMENTS \"Additional Comments\" true true false 255 Text 0 0,First,#,TIP_LINES,COMMENTS,0,255;CONSTCOMPLETEDATE \"Construction Complete Date\" true true false 5 Text 0 0,First,#,TIP_LINES,CONSTCOMPLETEDATE,0,5;PROJECTPHCOMPLETEDATE \"Project Phase Complete Date\" true true false 25 Text 0 0,First,#,TIP_LINES,PROJECTPHCOMPLETEDATE,0,25;Shape_Length_1 \"Shape_Length\" false true true 8 Double 0 0,First,#,TIP_LINES,Shape_Length,-1,-1", match_option="INTERSECT", search_radius="", distance_field_name="")

        # Process: Add Join (5) (Add Join) (management)
        if BL_JOIN and HW_JOIN and LOS_JOIN and Layer_With_Join_Removed and Layer_With_Join_Removed_2_ and Layer_With_Join_Removed_3_ and Layer_With_Join_Removed_4_ and MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_50_ and MAX_INDEX_LINES_56_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_ and TIPL_JOIN and VC_JOIN:
            MAX_INDEX_LINES_83_ = arcpy.management.AddJoin(in_layer_or_view=MAX_INDEX_LINES_60_, in_field="OBJECTID", join_table=TIPL_JOIN, join_field="OBJECTID", join_type="KEEP_ALL", index_join_fields="NO_INDEX_JOIN_FIELDS")[0]

        # Process: Calculate Field (29) (Calculate Field) (management)
        if BL_JOIN and HW_JOIN and LOS_JOIN and Layer_With_Join_Removed and Layer_With_Join_Removed_2_ and Layer_With_Join_Removed_3_ and Layer_With_Join_Removed_4_ and MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_50_ and MAX_INDEX_LINES_56_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_ and TIPL_JOIN and VC_JOIN:
            MAX_INDEX_LINES_84_ = arcpy.management.CalculateField(in_table=MAX_INDEX_LINES_83_, field="MAX_INDEX_LINES.TIPL_TOT", expression="calc_field(!MAX_INDEX_LINES.TIPL_TOT!,!TIPL_JOIN.Join_Count!)", expression_type="PYTHON3", code_block="""def calc_field(TIPL_TOT, JOIN_COUNT):
    if JOIN_COUNT == 0:
        return(1 * TIPL_TOT)
    else:
        return(TIPL_TOT * JOIN_COUNT)""", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Remove Join (5) (Remove Join) (management)
        if BL_JOIN and HW_JOIN and LOS_JOIN and Layer_With_Join_Removed and Layer_With_Join_Removed_2_ and Layer_With_Join_Removed_3_ and Layer_With_Join_Removed_4_ and MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_50_ and MAX_INDEX_LINES_56_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_ and TIPL_JOIN and VC_JOIN:
            Layer_With_Join_Removed_5_ = arcpy.management.RemoveJoin(in_layer_or_view=MAX_INDEX_LINES_84_, join_name="TIPL_JOIN")[0]

        # Process: Spatial Join (6) (Spatial Join) (analysis)
        TRL_JOIN = f"{Workspace}\\TRL_JOIN"
        if BL_JOIN and HW_JOIN and LOS_JOIN and Layer_With_Join_Removed and Layer_With_Join_Removed_2_ and Layer_With_Join_Removed_3_ and Layer_With_Join_Removed_4_ and Layer_With_Join_Removed_5_ and MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_50_ and MAX_INDEX_LINES_56_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_ and TIPL_JOIN and VC_JOIN:
            arcpy.analysis.SpatialJoin(target_features=MAX_INDEX_LINES_37_, join_features=TRAILS_2_, out_feature_class=TRL_JOIN, join_operation="JOIN_ONE_TO_ONE", join_type="KEEP_ALL", field_mapping="Shape_Length \"Shape_Length\" false true true 8 Double 0 0,First,#,MAX_INDEX_LINES,Shape_Length,-1,-1;Shape_Area \"Shape_Area\" false true true 8 Double 0 0,First,#,MAX_INDEX_LINES,Shape_Area,-1,-1;BL_MAX \"BL_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,BL_MAX,-1,-1;BL_QTR \"BL_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,BL_QTR,-1,-1;BL_HLF \"BL_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,BL_HLF,-1,-1;BL_TOT \"BL_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,BL_TOT,-1,-1;HW_MAX \"HW_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,HW_MAX,-1,-1;HW_QTR \"HW_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,HW_QTR,-1,-1;HW_HLF \"HW_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,HW_HLF,-1,-1;HW_TOT \"HW_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,HW_TOT,-1,-1;LOS_MAX \"LOS_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,LOS_MAX,-1,-1;LOS_QTR \"LOS_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,LOS_QTR,-1,-1;LOS_HLF \"LOS_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,LOS_HLF,-1,-1;LOS_TOT \"LOS_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,LOS_TOT,-1,-1;VC_MAX \"VC_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,VC_MAX,-1,-1;VC_QTR \"VC_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,VC_QTR,-1,-1;VC_HLF \"VC_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,VC_HLF,-1,-1;VC_TOT \"VC_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,VC_TOT,-1,-1;TIPL_MAX \"TIPL_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TIPL_MAX,-1,-1;TIPL_QTR \"TIPL_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TIPL_QTR,-1,-1;TIPL_HLF \"TIPL_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TIPL_HLF,-1,-1;TIPL_TOT \"TIPL_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TIPL_TOT,-1,-1;TRL_MAX \"TRL_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TRL_MAX,-1,-1;TRL_QTR \"TRL_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TRL_QTR,-1,-1;TRL_HLF \"TRL_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TRL_HLF,-1,-1;TRL_TOT \"TRL_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TRL_TOT,-1,-1;SHR_MAX \"SHR_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,SHR_MAX,-1,-1;SHR_QTR \"SHR_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,SHR_QTR,-1,-1;SHR_HLF \"SHR_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,SHR_HLF,-1,-1;SHR_TOT \"SHR_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,SHR_TOT,-1,-1;TOT_LIN \"TOT_LIN\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TOT_LIN,-1,-1;OBJECTID_1 \"OBJECTID_1\" true true false 4 Long 0 0,First,#,TRAILS,OBJECTID_1,-1,-1;OBJECTID \"OBJECTID\" true true false 4 Long 0 0,First,#,TRAILS,OBJECTID,-1,-1;FACILITYID \"FACILITYID\" true true false 50 Text 0 0,First,#,TRAILS,FACILITYID,0,50;NAME \"NAME\" true true false 254 Text 0 0,First,#,TRAILS,NAME,0,254;LENGTH \"LENGTH\" true true false 8 Double 0 0,First,#,TRAILS,LENGTH,-1,-1;OWNEDBY \"OWNEDBY\" true true false 4 Long 0 0,First,#,TRAILS,OWNEDBY,-1,-1;MAINTBY \"MAINTBY\" true true false 4 Long 0 0,First,#,TRAILS,MAINTBY,-1,-1;COMMENTS \"COMMENTS\" true true false 254 Text 0 0,First,#,TRAILS,COMMENTS,0,254;TRAILTYPE \"TRAILTYPE\" true true false 50 Text 0 0,First,#,TRAILS,TRAILTYPE,0,50;STATUS \"STATUS\" true true false 50 Text 0 0,First,#,TRAILS,STATUS,0,50;RESPONSIBL \"RESPONSIBL\" true true false 254 Text 0 0,First,#,TRAILS,RESPONSIBL,0,254;JURISDICTI \"JURISDICTI\" true true false 254 Text 0 0,First,#,TRAILS,JURISDICTI,0,254;APPROXCOST \"APPROXCOST\" true true false 4 Long 0 0,First,#,TRAILS,APPROXCOST,-1,-1;FUNDINGSOU \"FUNDINGSOU\" true true false 30 Text 0 0,First,#,TRAILS,FUNDINGSOU,0,30;FISCALYEAR \"FISCALYEAR\" true true false 11 Text 0 0,First,#,TRAILS,FISCALYEAR,0,11;CATEGORY \"CATEGORY\" true true false 40 Text 0 0,First,#,TRAILS,CATEGORY,0,40;DESIGNATED \"DESIGNATED\" true true false 1 Text 0 0,First,#,TRAILS,DESIGNATED,0,1;FUNDED \"FUNDED\" true true false 1 Text 0 0,First,#,TRAILS,FUNDED,0,1;THELOOP \"THELOOP\" true true false 1 Text 0 0,First,#,TRAILS,THELOOP,0,1;AREAID1 \"AREAID1\" true true false 4 Long 0 0,First,#,TRAILS,AREAID1,-1,-1;AREAID2 \"AREAID2\" true true false 4 Long 0 0,First,#,TRAILS,AREAID2,-1,-1;AREAID3 \"AREAID3\" true true false 4 Long 0 0,First,#,TRAILS,AREAID3,-1,-1;GLOBALID \"GLOBALID\" true true false 38 Text 0 0,First,#,TRAILS,GLOBALID,0,38;CREATED_US \"CREATED_US\" true true false 254 Text 0 0,First,#,TRAILS,CREATED_US,0,254;CREATED_DA \"CREATED_DA\" true true false 8 Date 0 0,First,#,TRAILS,CREATED_DA,-1,-1;LAST_EDITE \"LAST_EDITE\" true true false 254 Text 0 0,First,#,TRAILS,LAST_EDITE,0,254;LAST_EDI_1 \"LAST_EDI_1\" true true false 8 Date 0 0,First,#,TRAILS,LAST_EDI_1,-1,-1;ADOPTED \"ADOPTED\" true true false 8 Date 0 0,First,#,TRAILS,ADOPTED,-1,-1;COMPLETED \"COMPLETED\" true true false 8 Date 0 0,First,#,TRAILS,COMPLETED,-1,-1;WIDTH \"WIDTH\" true true false 15 Text 0 0,First,#,TRAILS,WIDTH,0,15;SHAPE_STLe \"SHAPE_STLe\" true true false 8 Double 0 0,First,#,TRAILS,SHAPE_STLe,-1,-1;Shape_Leng \"Shape_Leng\" true true false 8 Double 0 0,First,#,TRAILS,Shape_Leng,-1,-1;Shape_Length_1 \"Shape_Length\" false true true 8 Double 0 0,First,#,TRAILS,Shape_Length,-1,-1", match_option="INTERSECT", search_radius="", distance_field_name="")

        # Process: Add Join (6) (Add Join) (management)
        if BL_JOIN and HW_JOIN and LOS_JOIN and Layer_With_Join_Removed and Layer_With_Join_Removed_2_ and Layer_With_Join_Removed_3_ and Layer_With_Join_Removed_4_ and Layer_With_Join_Removed_5_ and MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_50_ and MAX_INDEX_LINES_56_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_ and TIPL_JOIN and TRL_JOIN and VC_JOIN:
            MAX_INDEX_LINES_85_ = arcpy.management.AddJoin(in_layer_or_view=MAX_INDEX_LINES_35_, in_field="OBJECTID", join_table=TRL_JOIN, join_field="OBJECTID", join_type="KEEP_ALL", index_join_fields="NO_INDEX_JOIN_FIELDS")[0]

        # Process: Calculate Field (34) (Calculate Field) (management)
        if BL_JOIN and HW_JOIN and LOS_JOIN and Layer_With_Join_Removed and Layer_With_Join_Removed_2_ and Layer_With_Join_Removed_3_ and Layer_With_Join_Removed_4_ and Layer_With_Join_Removed_5_ and MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_50_ and MAX_INDEX_LINES_56_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_ and TIPL_JOIN and TRL_JOIN and VC_JOIN:
            MAX_INDEX_LINES_86_ = arcpy.management.CalculateField(in_table=MAX_INDEX_LINES_85_, field="MAX_INDEX_LINES.TRL_TOT", expression="calc_field(!MAX_INDEX_LINES.TRL_TOT!,!TRL_JOIN.Join_Count!)", expression_type="PYTHON3", code_block="""def calc_field(TRL_TOT, JOIN_COUNT):
    if JOIN_COUNT == 0:
        return(1 * TRL_TOT)
    else:
        return(TRL_TOT * JOIN_COUNT)""", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Remove Join (6) (Remove Join) (management)
        if BL_JOIN and HW_JOIN and LOS_JOIN and Layer_With_Join_Removed and Layer_With_Join_Removed_2_ and Layer_With_Join_Removed_3_ and Layer_With_Join_Removed_4_ and Layer_With_Join_Removed_5_ and MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_50_ and MAX_INDEX_LINES_56_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_ and TIPL_JOIN and TRL_JOIN and VC_JOIN:
            Layer_With_Join_Removed_6_ = arcpy.management.RemoveJoin(in_layer_or_view=MAX_INDEX_LINES_86_, join_name="TRL_JOIN")[0]

        # Process: Spatial Join (7) (Spatial Join) (analysis)
        SHR_JOIN = f"{Workspace}\\SHR_JOIN"
        if BL_JOIN and HW_JOIN and LOS_JOIN and Layer_With_Join_Removed and Layer_With_Join_Removed_2_ and Layer_With_Join_Removed_3_ and Layer_With_Join_Removed_4_ and Layer_With_Join_Removed_5_ and Layer_With_Join_Removed_6_ and MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_50_ and MAX_INDEX_LINES_56_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_ and TIPL_JOIN and TRL_JOIN and VC_JOIN:
            arcpy.analysis.SpatialJoin(target_features=MAX_INDEX_LINES_31_, join_features=Sharrows_2_, out_feature_class=SHR_JOIN, join_operation="JOIN_ONE_TO_ONE", join_type="KEEP_ALL", field_mapping="Shape_Length \"Shape_Length\" false true true 8 Double 0 0,First,#,MAX_INDEX_LINES,Shape_Length,-1,-1;Shape_Area \"Shape_Area\" false true true 8 Double 0 0,First,#,MAX_INDEX_LINES,Shape_Area,-1,-1;BL_MAX \"BL_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,BL_MAX,-1,-1;BL_QTR \"BL_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,BL_QTR,-1,-1;BL_HLF \"BL_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,BL_HLF,-1,-1;BL_TOT \"BL_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,BL_TOT,-1,-1;HW_MAX \"HW_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,HW_MAX,-1,-1;HW_QTR \"HW_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,HW_QTR,-1,-1;HW_HLF \"HW_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,HW_HLF,-1,-1;HW_TOT \"HW_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,HW_TOT,-1,-1;LOS_MAX \"LOS_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,LOS_MAX,-1,-1;LOS_QTR \"LOS_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,LOS_QTR,-1,-1;LOS_HLF \"LOS_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,LOS_HLF,-1,-1;LOS_TOT \"LOS_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,LOS_TOT,-1,-1;VC_MAX \"VC_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,VC_MAX,-1,-1;VC_QTR \"VC_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,VC_QTR,-1,-1;VC_HLF \"VC_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,VC_HLF,-1,-1;VC_TOT \"VC_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,VC_TOT,-1,-1;TIPL_MAX \"TIPL_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TIPL_MAX,-1,-1;TIPL_QTR \"TIPL_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TIPL_QTR,-1,-1;TIPL_HLF \"TIPL_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TIPL_HLF,-1,-1;TIPL_TOT \"TIPL_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TIPL_TOT,-1,-1;TRL_MAX \"TRL_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TRL_MAX,-1,-1;TRL_QTR \"TRL_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TRL_QTR,-1,-1;TRL_HLF \"TRL_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TRL_HLF,-1,-1;TRL_TOT \"TRL_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TRL_TOT,-1,-1;SHR_MAX \"SHR_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,SHR_MAX,-1,-1;SHR_QTR \"SHR_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,SHR_QTR,-1,-1;SHR_HLF \"SHR_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,SHR_HLF,-1,-1;SHR_TOT \"SHR_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,SHR_TOT,-1,-1;TOT_LIN \"TOT_LIN\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,TOT_LIN,-1,-1;FACILITYID \"Facility Identifier\" true true false 50 Text 0 0,First,#,Sharrows,FACILITYID,0,50;NAME \"Trail Name\" true true false 255 Text 0 0,First,#,Sharrows,NAME,0,255;LENGTH \"Length/Miles\" true true false 8 Double 0 0,First,#,Sharrows,LENGTH,-1,-1;OWNEDBY \"Owned By\" true true false 2 Short 0 0,First,#,Sharrows,OWNEDBY,-1,-1;MAINTBY \"Managed By\" true true false 2 Short 0 0,First,#,Sharrows,MAINTBY,-1,-1;COMMENTS \"Comments\" true true false 255 Text 0 0,First,#,Sharrows,COMMENTS,0,255;TRAILTYPE \"Trail Type\" true true false 50 Text 0 0,First,#,Sharrows,TRAILTYPE,0,50;STATUS \"Status\" true true false 50 Text 0 0,First,#,Sharrows,STATUS,0,50;RESPONSIBLEAGENCY \"Responsible Agency\" true true false 255 Text 0 0,First,#,Sharrows,RESPONSIBLEAGENCY,0,255;JURISDICTION \"Jurisdiction\" true true false 255 Text 0 0,First,#,Sharrows,JURISDICTION,0,255;APPROXCOST \"Approximate Cost\" true true false 4 Long 0 0,First,#,Sharrows,APPROXCOST,-1,-1;FUNDINGSOURCE \"Funding Source\" true true false 30 Text 0 0,First,#,Sharrows,FUNDINGSOURCE,0,30;FISCALYEAR \"Fiscal Year\" true true false 11 Text 0 0,First,#,Sharrows,FISCALYEAR,0,11;CATEGORY \"Category\" true true false 40 Text 0 0,First,#,Sharrows,CATEGORY,0,40;DESIGNATED \"Designated\" true true false 1 Text 0 0,First,#,Sharrows,DESIGNATED,0,1;FUNDED \"Funded\" true true false 1 Text 0 0,First,#,Sharrows,FUNDED,0,1;THELOOP \"Part of the Loop?\" true true false 1 Text 0 0,First,#,Sharrows,THELOOP,0,1;AREAID1 \"Area ID 1\" true true false 2 Short 0 0,First,#,Sharrows,AREAID1,-1,-1;AREAID2 \"Area ID 2\" true true false 2 Short 0 0,First,#,Sharrows,AREAID2,-1,-1;AREAID3 \"Area ID 3\" true true false 2 Short 0 0,First,#,Sharrows,AREAID3,-1,-1;CREATED_USER \"CREATED_USER\" true true false 255 Text 0 0,First,#,Sharrows,CREATED_USER,0,255;CREATED_DATE \"CREATED_DATE\" true true false 8 Date 0 0,First,#,Sharrows,CREATED_DATE,-1,-1;LAST_EDITED_USER \"LAST_EDITED_USER\" true true false 255 Text 0 0,First,#,Sharrows,LAST_EDITED_USER,0,255;LAST_EDITED_DATE \"LAST_EDITED_DATE\" true true false 8 Date 0 0,First,#,Sharrows,LAST_EDITED_DATE,-1,-1;ADOPTED \"ADOPTED\" true true false 8 Date 0 0,First,#,Sharrows,ADOPTED,-1,-1;COMPLETED \"Completed Date\" true true false 8 Date 0 0,First,#,Sharrows,COMPLETED,-1,-1;WIDTH \"Width/Feet\" true true false 15 Text 0 0,First,#,Sharrows,WIDTH,0,15;Shape_Length_1 \"Shape_Length\" false true true 8 Double 0 0,First,#,Sharrows,Shape_Length,-1,-1", match_option="INTERSECT", search_radius="", distance_field_name="")

        # Process: Add Join (7) (Add Join) (management)
        if BL_JOIN and HW_JOIN and LOS_JOIN and Layer_With_Join_Removed and Layer_With_Join_Removed_2_ and Layer_With_Join_Removed_3_ and Layer_With_Join_Removed_4_ and Layer_With_Join_Removed_5_ and Layer_With_Join_Removed_6_ and MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_50_ and MAX_INDEX_LINES_56_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_ and SHR_JOIN and TIPL_JOIN and TRL_JOIN and VC_JOIN:
            MAX_INDEX_LINES_87_ = arcpy.management.AddJoin(in_layer_or_view=MAX_INDEX_LINES_29_, in_field="OBJECTID", join_table=SHR_JOIN, join_field="OBJECTID", join_type="KEEP_ALL", index_join_fields="NO_INDEX_JOIN_FIELDS")[0]

        # Process: Calculate Field (35) (Calculate Field) (management)
        if BL_JOIN and HW_JOIN and LOS_JOIN and Layer_With_Join_Removed and Layer_With_Join_Removed_2_ and Layer_With_Join_Removed_3_ and Layer_With_Join_Removed_4_ and Layer_With_Join_Removed_5_ and Layer_With_Join_Removed_6_ and MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_50_ and MAX_INDEX_LINES_56_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_ and SHR_JOIN and TIPL_JOIN and TRL_JOIN and VC_JOIN:
            MAX_INDEX_LINES_88_ = arcpy.management.CalculateField(in_table=MAX_INDEX_LINES_87_, field="MAX_INDEX_LINES.SHR_TOT", expression="calc_field(!MAX_INDEX_LINES.SHR_TOT!,!SHR_JOIN.Join_Count!)", expression_type="PYTHON3", code_block="""def calc_field(SHR_TOT, JOIN_COUNT):
    if JOIN_COUNT == 0:
        return(1 * SHR_TOT)
    else:
        return(SHR_TOT * JOIN_COUNT)""", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Remove Join (7) (Remove Join) (management)
        if BL_JOIN and HW_JOIN and LOS_JOIN and Layer_With_Join_Removed and Layer_With_Join_Removed_2_ and Layer_With_Join_Removed_3_ and Layer_With_Join_Removed_4_ and Layer_With_Join_Removed_5_ and Layer_With_Join_Removed_6_ and MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_50_ and MAX_INDEX_LINES_56_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_ and SHR_JOIN and TIPL_JOIN and TRL_JOIN and VC_JOIN:
            Layer_With_Join_Removed_7_ = arcpy.management.RemoveJoin(in_layer_or_view=MAX_INDEX_LINES_88_, join_name="SHR_JOIN")[0]

        # Process: Calculate Field (36) (Calculate Field) (management)
        if BL_JOIN and HW_JOIN and LOS_JOIN and Layer_With_Join_Removed and Layer_With_Join_Removed_2_ and Layer_With_Join_Removed_3_ and Layer_With_Join_Removed_4_ and Layer_With_Join_Removed_5_ and Layer_With_Join_Removed_6_ and MAX_INDEX_LINES_17_ and MAX_INDEX_LINES_21_ and MAX_INDEX_LINES_23_ and MAX_INDEX_LINES_2_ and MAX_INDEX_LINES_33_ and MAX_INDEX_LINES_39_ and MAX_INDEX_LINES_42_ and MAX_INDEX_LINES_47_ and MAX_INDEX_LINES_50_ and MAX_INDEX_LINES_56_ and MAX_INDEX_LINES_61_ and MAX_INDEX_LINES_63_ and MAX_INDEX_LINES_66_ and MAX_INDEX_LINES_8_ and SHR_JOIN and TIPL_JOIN and TRL_JOIN and VC_JOIN:
            MAX_INDEX_LINES_89_ = arcpy.management.CalculateField(in_table=Layer_With_Join_Removed_7_, field="TOT_LIN", expression="!BL_TOT! + !HW_TOT! + !LOS_TOT! + !VC_TOT! + !TIPL_TOT! + !TRL_TOT! + !SHR_TOT!", expression_type="PYTHON3", code_block="", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

"""

PART 3: 

This process generates unique fields for point data imported within the Forward Pinellas MAX Index and sets them equal to zero. More information on how these are calculated and what they represent can be found in PART 4 below. 

MMT_MAX 
MMT_QTR 
MMT_HLF 
MMT_TOT 

BRT_MAX 
BRT_QTR 
BRT_HLF 
BRT_TOT 

TIPP_MAX 
TIPP_QTR 
TIPP_HLF 
TIPP_TOT 

BUS_MAX 
BUS_QTR 
BUS_HLF 
BUS_TOT

POINT_TOT
"""

maxInputFeaturesPoints = arcpy.GetParameterAsText(9) # input the exported MAX Index fishnet feature for MAX Index Points data

def createFieldsPoints():  # Test3

    # To allow overwriting outputs change overwriteOutput option to True.
    arcpy.env.overwriteOutput = True

    MAX_INDEX_POINTS = maxInputFeaturesPoints

    # Process: Add Field (Add Field) (management)
    MAX_INDEX_POINTS_2_ = arcpy.management.AddField(in_table=MAX_INDEX_POINTS, field_name="MMT_MAX", field_type="DOUBLE", field_precision=4, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (2) (Add Field) (management)
    MAX_INDEX_POINTS_3_ = arcpy.management.AddField(in_table=MAX_INDEX_POINTS_2_, field_name="MMT_QTR", field_type="DOUBLE", field_precision=4, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (3) (Add Field) (management)
    MAX_INDEX_POINTS_4_ = arcpy.management.AddField(in_table=MAX_INDEX_POINTS_3_, field_name="MMT_HLF", field_type="DOUBLE", field_precision=4, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (4) (Add Field) (management)
    MAX_INDEX_POINTS_5_ = arcpy.management.AddField(in_table=MAX_INDEX_POINTS_4_, field_name="MMT_TOT", field_type="DOUBLE", field_precision=4, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (5) (Add Field) (management)
    MAX_INDEX_POINTS_6_ = arcpy.management.AddField(in_table=MAX_INDEX_POINTS_5_, field_name="BRT_MAX", field_type="DOUBLE", field_precision=4, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (6) (Add Field) (management)
    MAX_INDEX_POINTS_7_ = arcpy.management.AddField(in_table=MAX_INDEX_POINTS_6_, field_name="BRT_QTR", field_type="DOUBLE", field_precision=4, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (7) (Add Field) (management)
    MAX_INDEX_POINTS_8_ = arcpy.management.AddField(in_table=MAX_INDEX_POINTS_7_, field_name="BRT_HLF", field_type="DOUBLE", field_precision=4, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (8) (Add Field) (management)
    MAX_INDEX_POINTS_9_ = arcpy.management.AddField(in_table=MAX_INDEX_POINTS_8_, field_name="BRT_TOT", field_type="DOUBLE", field_precision=4, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (9) (Add Field) (management)
    MAX_INDEX_POINTS_10_ = arcpy.management.AddField(in_table=MAX_INDEX_POINTS_9_, field_name="TIPP_MAX", field_type="DOUBLE", field_precision=4, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (10) (Add Field) (management)
    MAX_INDEX_POINTS_11_ = arcpy.management.AddField(in_table=MAX_INDEX_POINTS_10_, field_name="TIPP_QTR", field_type="DOUBLE", field_precision=4, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (11) (Add Field) (management)
    MAX_INDEX_POINTS_12_ = arcpy.management.AddField(in_table=MAX_INDEX_POINTS_11_, field_name="TIPP_HLF", field_type="DOUBLE", field_precision=4, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (12) (Add Field) (management)
    MAX_INDEX_POINTS_13_ = arcpy.management.AddField(in_table=MAX_INDEX_POINTS_12_, field_name="TIPP_TOT", field_type="DOUBLE", field_precision=4, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (13) (Add Field) (management)
    MAX_INDEX_POINTS_14_ = arcpy.management.AddField(in_table=MAX_INDEX_POINTS_13_, field_name="BUS_MAX", field_type="DOUBLE", field_precision=4, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (14) (Add Field) (management)
    MAX_INDEX_POINTS_15_ = arcpy.management.AddField(in_table=MAX_INDEX_POINTS_14_, field_name="BUS_QTR", field_type="DOUBLE", field_precision=4, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (15) (Add Field) (management)
    MAX_INDEX_POINTS_16_ = arcpy.management.AddField(in_table=MAX_INDEX_POINTS_15_, field_name="BUS_HLF", field_type="DOUBLE", field_precision=4, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (16) (Add Field) (management)
    MAX_INDEX_POINTS_17_ = arcpy.management.AddField(in_table=MAX_INDEX_POINTS_16_, field_name="BUS_TOT", field_type="DOUBLE", field_precision=4, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Add Field (17) (Add Field) (management)
    MAX_INDEX_POINTS_19_ = arcpy.management.AddField(in_table=MAX_INDEX_POINTS_17_, field_name="POINT_TOT", field_type="DOUBLE", field_precision=4, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

    # Process: Calculate Fields (multiple) (Calculate Fields (multiple)) (management)
    if MAX_INDEX_POINTS_19_:
        MAX_INDEX_POINTS_18_ = arcpy.management.CalculateFields(in_table=MAX_INDEX_POINTS_19_, expression_type="PYTHON3", fields=[["MMT_MAX", "0"], ["MMT_QTR", "0"], ["MMT_HLF", "0"], ["MMT_TOT", "0"], ["BRT_MAX", "0"], ["BRT_QTR", "0"], ["BRT_HLF", "0"], ["BRT_TOT", "0"], ["TIPP_MAX", "0"], ["TIPP_QTR", "0"], ["TIPP_HLF", "0"], ["TIPP_TOT", "0"], ["BUS_MAX", "0"], ["BUS_QTR", "0"], ["BUS_HLF", "0"], ["BUS_TOT", "0"], ["POINT_TOT", "0"]], code_block="", enforce_domains="NO_ENFORCE_DOMAINS")[0]


"""
PART 4:

This process calculates fields for the MAX Index grid associated with point data.

MMT_MAX = Score associated with the presence of micromobility options directly in a grid cell. Maximum score if micromobility options are present is 1
MMT_QTR = Score associated with the presence of micromobility options within a quarter mile of the grid cell. Maximum score if micromobility options are present within a quarter mile is 0.5
MMT_HLF = Score associated with the presence of micromobility options within a half mile of the grid cell. Maximum score if micromobility options are present within a half mile is 0.25
MMT_TOT = The sum of MMT_MAX (multiplied by the number of features present in the grid cell), MMT_QTR, and MMT_TOT. 

BRT_MAX = Score associated with the presence of bus rapid transit stops directly in a grid cell. Maximum score if bus rapid transit stops are present is 3
BRT_QTR = Score associated with the presence of bus rapid transit stops or less within a quarter mile of the grid cell. Maximum score if bus rapid transit stops are present within a quarter mile is 1.5
BRT_HLF = Score associated with the presence of bus rapid transit stops or less within a half mile of the grid cell. Maximum score if bus rapid transit stops are present within a half mile is 0.75
BRT_TOT = The sum of BRT_MAX (multiplied by the number of features present in the grid cell), BRT_QTR, and BRT_TOT.

TIPP_MAX = Score associated with the presence of TIP project points directly in a grid cell. Maximum score if a TIP project point is present is 1
TIPP_QTR = Score associated with the presence of TIP project points within a quarter mile of the grid cell. Maximum score if a TIP project point is present within a quarter mile is 0.5
TIPP_HLF = Score associated with the presence of TIP project points within a half mile of the grid cell. Maximum score if a TIP project point is present within a half mile is 0.25
TIPP_TOT = The sum of TIPP_MAX (multiplied by the number of features present in the grid cell), TIPP_QTR, and TIPP_TOT.

BUS_MAX = Score associated with the presence of bus stops directly in a grid cell. Maximum score if bus stops are present is 1
BUS_QTR = Score associated with the presence of bus stops within a quarter mile of the grid cell. Maximum score if bus stops are present within a quarter mile is 0.5
BUS_HLF = Score associated with the presence of bus stops within a half mile of the grid cell. Maximum score if bus stops are present within a half mile is 0.25
BUS_TOT = The sum of BUS_MAX (multiplied by the number of features present in the grid cell), BUS_QTR, and BUS_TOT.

POINT_TOT = sum of the following: MMT_TOT, BRT_TOT, TIPP_TOT, BUS_TOT

Additional field calculation scripts are in place to prevent fields from being double counted in total point calculation.
"""

bikeShareLocations = arcpy.GetParameterAsText(10) # input micromobility features
tip_Points = arcpy.GetParameterAsText(11) # input TIP Point features
brt_Stations = arcpy.GetParameterAsText(12) # input BRT bus station features
bus_Stops = arcpy.GetParameterAsText(13) # input bus stop features

def calculateFieldsPoints():  # Calculates each newly created field for the MAX Index Points grid

    # To allow overwriting outputs change overwriteOutput option to True.
    arcpy.env.overwriteOutput = True

    MAX_INDEX_POINTS = maxInputFeaturesPoints
    BikeShareLocations = bikeShareLocations
    MAX_INDEX_POINTS_8_ = maxInputFeaturesPoints
    BRT_Stations = brt_Stations
    MAX_INDEX_POINTS_6_ = maxInputFeaturesPoints
    TIP_Points_WConstruction = tip_Points
    MAX_INDEX_POINTS_23_ = maxInputFeaturesPoints
    PSTA_Bus_Stops = bus_Stops
    MAX_INDEX_POINTS_22_ = maxInputFeaturesPoints
    PSTA_Bus_Stops_2_ = bus_Stops
    MAX_INDEX_POINTS_32_ = maxInputFeaturesPoints
    TIP_Points_WConstruction_2_ = tip_Points
    MAX_INDEX_POINTS_33_ = maxInputFeaturesPoints
    BRT_Stations_2_ = brt_Stations
    MAX_INDEX_POINTS_34_ = maxInputFeaturesPoints
    BikeShareLocations_2_ = bikeShareLocations

    # Process: Select Layer By Location (Select Layer By Location) (management)
    with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
        Layer_With_Selection, Output_Layer_Names, Count = arcpy.management.SelectLayerByLocation(in_layer=[MAX_INDEX_POINTS], overlap_type="INTERSECT", select_features=BikeShareLocations, search_distance="", selection_type="NEW_SELECTION", invert_spatial_relationship="NOT_INVERT")

    # Process: Calculate Field (Calculate Field) (management)
    with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
        MAX_INDEX_POINTS_2_ = arcpy.management.CalculateField(in_table=Layer_With_Selection, field="MMT_MAX", expression="1", expression_type="PYTHON3", code_block="", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

    # Process: Select Layer By Location (2) (Select Layer By Location) (management)
    with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
        MAX_INDEX_POINTS_3_, Output_Layer_Names_2_, Count_2_ = arcpy.management.SelectLayerByLocation(in_layer=[MAX_INDEX_POINTS_2_], overlap_type="INTERSECT", select_features=BikeShareLocations, search_distance="1320 Feet", selection_type="NEW_SELECTION", invert_spatial_relationship="NOT_INVERT")

    # Process: Calculate Field (2) (Calculate Field) (management)
    with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
        MAX_INDEX_POINTS_14_ = arcpy.management.CalculateField(in_table=MAX_INDEX_POINTS_3_, field="MMT_QTR", expression="calc_field(!MMT_MAX!,!MMT_QTR!)", expression_type="PYTHON3", code_block="""def calc_field(MMT_MAX, MMT_QTR):
    if MMT_MAX == 0:
        return 0.5
    else: 
        return 0""", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

    # Process: Select Layer By Location (3) (Select Layer By Location) (management)
    with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
        MAX_INDEX_POINTS_5_, Output_Layer_Names_3_, Count_3_ = arcpy.management.SelectLayerByLocation(in_layer=[MAX_INDEX_POINTS_14_], overlap_type="INTERSECT", select_features=BikeShareLocations, search_distance="2640 Feet", selection_type="NEW_SELECTION", invert_spatial_relationship="NOT_INVERT")

    # Process: Calculate Field (3) (Calculate Field) (management)
    with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
        MAX_INDEX_POINTS_4_ = arcpy.management.CalculateField(in_table=MAX_INDEX_POINTS_5_, field="MMT_HLF", expression="calc_field(!MMT_MAX!,!MMT_QTR!,!MMT_HLF!)", expression_type="PYTHON3", code_block="""def calc_field(MMT_MAX, MMT_QTR, MMT_HLF):
    if MMT_MAX == 0 and MMT_QTR == 0:
        return 0.25
    else: 
        return 0""", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

    # Process: Calculate Field (4) (Calculate Field) (management)
    with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
        MAX_INDEX_POINTS_7_ = arcpy.management.CalculateField(in_table=MAX_INDEX_POINTS_4_, field="MMT_TOT", expression="!MMT_MAX! + !MMT_QTR! + !MMT_HLF!", expression_type="PYTHON3", code_block="", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

    # Process: Select Layer By Location (4) (Select Layer By Location) (management)
    if MAX_INDEX_POINTS_7_:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            Layer_With_Selection_2_, Output_Layer_Names_4_, Count_4_ = arcpy.management.SelectLayerByLocation(in_layer=[MAX_INDEX_POINTS_8_], overlap_type="INTERSECT", select_features=BRT_Stations, search_distance="", selection_type="NEW_SELECTION", invert_spatial_relationship="NOT_INVERT")

    # Process: Calculate Field (5) (Calculate Field) (management)
    if MAX_INDEX_POINTS_7_:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            MAX_INDEX_POINTS_15_ = arcpy.management.CalculateField(in_table=Layer_With_Selection_2_, field="BRT_MAX", expression="3", expression_type="PYTHON3", code_block="", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

    # Process: Select Layer By Location (5) (Select Layer By Location) (management)
    if MAX_INDEX_POINTS_7_:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            MAX_INDEX_POINTS_10_, Output_Layer_Names_5_, Count_5_ = arcpy.management.SelectLayerByLocation(in_layer=[MAX_INDEX_POINTS_15_], overlap_type="INTERSECT", select_features=BRT_Stations, search_distance="1320 Feet", selection_type="NEW_SELECTION", invert_spatial_relationship="NOT_INVERT")

    # Process: Calculate Field (6) (Calculate Field) (management)
    if MAX_INDEX_POINTS_7_:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            MAX_INDEX_POINTS_11_ = arcpy.management.CalculateField(in_table=MAX_INDEX_POINTS_10_, field="BRT_QTR", expression="calc_field(!BRT_MAX!,!BRT_QTR!)", expression_type="PYTHON3", code_block="""def calc_field(BRT_MAX, BRT_QTR):
    if BRT_MAX == 0:
        return 1.5
    else: 
        return 0""", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

    # Process: Select Layer By Location (6) (Select Layer By Location) (management)
    if MAX_INDEX_POINTS_7_:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            MAX_INDEX_POINTS_12_, Output_Layer_Names_6_, Count_6_ = arcpy.management.SelectLayerByLocation(in_layer=[MAX_INDEX_POINTS_11_], overlap_type="INTERSECT", select_features=BRT_Stations, search_distance="2640 Feet", selection_type="NEW_SELECTION", invert_spatial_relationship="NOT_INVERT")

    # Process: Calculate Field (7) (Calculate Field) (management)
    if MAX_INDEX_POINTS_7_:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            MAX_INDEX_POINTS_13_ = arcpy.management.CalculateField(in_table=MAX_INDEX_POINTS_12_, field="BRT_HLF", expression="calc_field(!BRT_MAX!,!BRT_QTR!,!BRT_HLF!)", expression_type="PYTHON3", code_block="""def calc_field(BRT_MAX, BRT_QTR, BRT_HLF):
    if BRT_MAX == 0 and BRT_QTR==0:
        return 0.75
    else: 
        return 0""", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

    # Process: Calculate Field (8) (Calculate Field) (management)
    if MAX_INDEX_POINTS_7_:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            MAX_INDEX_POINTS_9_ = arcpy.management.CalculateField(in_table=MAX_INDEX_POINTS_13_, field="BRT_TOT", expression="!BRT_MAX! + !BRT_QTR! + !BRT_HLF!", expression_type="PYTHON3", code_block="", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

    # Process: Select Layer By Location (7) (Select Layer By Location) (management)
    if MAX_INDEX_POINTS_7_ and MAX_INDEX_POINTS_9_:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            Layer_With_Selection_3_, Output_Layer_Names_7_, Count_7_ = arcpy.management.SelectLayerByLocation(in_layer=[MAX_INDEX_POINTS_6_], overlap_type="INTERSECT", select_features=TIP_Points_WConstruction, search_distance="", selection_type="NEW_SELECTION", invert_spatial_relationship="NOT_INVERT")

    # Process: Calculate Field (10) (Calculate Field) (management)
    if MAX_INDEX_POINTS_7_ and MAX_INDEX_POINTS_9_:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            MAX_INDEX_POINTS_19_ = arcpy.management.CalculateField(in_table=Layer_With_Selection_3_, field="TIPP_MAX", expression="1", expression_type="PYTHON3", code_block="", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

    # Process: Select Layer By Location (8) (Select Layer By Location) (management)
    if MAX_INDEX_POINTS_7_ and MAX_INDEX_POINTS_9_:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            MAX_INDEX_POINTS_18_, Output_Layer_Names_8_, Count_8_ = arcpy.management.SelectLayerByLocation(in_layer=[MAX_INDEX_POINTS_19_], overlap_type="INTERSECT", select_features=TIP_Points_WConstruction, search_distance="1320 Feet", selection_type="NEW_SELECTION", invert_spatial_relationship="NOT_INVERT")

    # Process: Calculate Field (11) (Calculate Field) (management)
    if MAX_INDEX_POINTS_7_ and MAX_INDEX_POINTS_9_:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            MAX_INDEX_POINTS_17_ = arcpy.management.CalculateField(in_table=MAX_INDEX_POINTS_18_, field="TIPP_QTR", expression="calc_field(!TIPP_MAX!,!TIPP_QTR!)", expression_type="PYTHON3", code_block="""def calc_field(TIPP_MAX, TIPP_QTR):
    if TIPP_MAX == 0:
        return 0.5
    else: 
        return 0""", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

    # Process: Select Layer By Location (9) (Select Layer By Location) (management)
    if MAX_INDEX_POINTS_7_ and MAX_INDEX_POINTS_9_:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            MAX_INDEX_POINTS_20_, Output_Layer_Names_9_, Count_9_ = arcpy.management.SelectLayerByLocation(in_layer=[MAX_INDEX_POINTS_17_], overlap_type="INTERSECT", select_features=TIP_Points_WConstruction, search_distance="2640 Feet", selection_type="NEW_SELECTION", invert_spatial_relationship="NOT_INVERT")

    # Process: Calculate Field (12) (Calculate Field) (management)
    if MAX_INDEX_POINTS_7_ and MAX_INDEX_POINTS_9_:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            MAX_INDEX_POINTS_21_ = arcpy.management.CalculateField(in_table=MAX_INDEX_POINTS_20_, field="TIPP_HLF", expression="calc_field(!TIPP_MAX!,!TIPP_QTR!,!TIPP_HLF!)", expression_type="PYTHON3", code_block="""def calc_field(TIPP_MAX, TIPP_QTR, TIPP_HLF):
    if TIPP_MAX == 0 and TIPP_QTR == 0:
        return 0.25
    else: 
        return 0""", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

    # Process: Calculate Field (13) (Calculate Field) (management)
    if MAX_INDEX_POINTS_7_ and MAX_INDEX_POINTS_9_:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            MAX_INDEX_POINTS_30_ = arcpy.management.CalculateField(in_table=MAX_INDEX_POINTS_21_, field="TIPP_TOT", expression="!TIPP_MAX! + !TIPP_QTR! + !TIPP_HLF!", expression_type="PYTHON3", code_block="", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

    # Process: Calculate Field (9) (Calculate Field) (management)
    if MAX_INDEX_POINTS_7_ and MAX_INDEX_POINTS_9_:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            MAX_INDEX_POINTS_16_ = arcpy.management.CalculateField(in_table=MAX_INDEX_POINTS_30_, field="TIPP_TOT", expression="!TIPP_MAX! + !TIPP_HLF! + !TIPP_QTR!", expression_type="PYTHON3", code_block="", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

    # Process: Select Layer By Location (10) (Select Layer By Location) (management)
    if MAX_INDEX_POINTS_16_ and MAX_INDEX_POINTS_7_ and MAX_INDEX_POINTS_9_:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            Layer_With_Selection_4_, Output_Layer_Names_10_, Count_10_ = arcpy.management.SelectLayerByLocation(in_layer=[MAX_INDEX_POINTS_23_], overlap_type="INTERSECT", select_features=PSTA_Bus_Stops, search_distance="", selection_type="NEW_SELECTION", invert_spatial_relationship="NOT_INVERT")

    # Process: Calculate Field (15) (Calculate Field) (management)
    if MAX_INDEX_POINTS_16_ and MAX_INDEX_POINTS_7_ and MAX_INDEX_POINTS_9_:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            MAX_INDEX_POINTS_24_ = arcpy.management.CalculateField(in_table=Layer_With_Selection_4_, field="BUS_MAX", expression="1", expression_type="PYTHON3", code_block="", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

    # Process: Select Layer By Location (11) (Select Layer By Location) (management)
    if MAX_INDEX_POINTS_16_ and MAX_INDEX_POINTS_7_ and MAX_INDEX_POINTS_9_:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            MAX_INDEX_POINTS_26_, Output_Layer_Names_11_, Count_11_ = arcpy.management.SelectLayerByLocation(in_layer=[MAX_INDEX_POINTS_24_], overlap_type="INTERSECT", select_features=PSTA_Bus_Stops, search_distance="1320 Feet", selection_type="NEW_SELECTION", invert_spatial_relationship="NOT_INVERT")

    # Process: Calculate Field (16) (Calculate Field) (management)
    if MAX_INDEX_POINTS_16_ and MAX_INDEX_POINTS_7_ and MAX_INDEX_POINTS_9_:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            MAX_INDEX_POINTS_25_ = arcpy.management.CalculateField(in_table=MAX_INDEX_POINTS_26_, field="BUS_QTR", expression="calc_field(!BUS_MAX!,!BUS_QTR!)", expression_type="PYTHON3", code_block="""def calc_field(BUS_MAX, BUS_QTR):
    if BUS_MAX == 0:
        return 0.5
    else: 
        return 0""", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

    # Process: Select Layer By Location (12) (Select Layer By Location) (management)
    if MAX_INDEX_POINTS_16_ and MAX_INDEX_POINTS_7_ and MAX_INDEX_POINTS_9_:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            MAX_INDEX_POINTS_28_, Output_Layer_Names_12_, Count_12_ = arcpy.management.SelectLayerByLocation(in_layer=[MAX_INDEX_POINTS_25_], overlap_type="INTERSECT", select_features=PSTA_Bus_Stops, search_distance="2640 Feet", selection_type="NEW_SELECTION", invert_spatial_relationship="NOT_INVERT")

    # Process: Calculate Field (17) (Calculate Field) (management)
    if MAX_INDEX_POINTS_16_ and MAX_INDEX_POINTS_7_ and MAX_INDEX_POINTS_9_:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            MAX_INDEX_POINTS_27_ = arcpy.management.CalculateField(in_table=MAX_INDEX_POINTS_28_, field="BUS_HLF", expression="calc_field(!BUS_MAX!,!BUS_QTR!,!BUS_HLF!)", expression_type="PYTHON3", code_block="""def calc_field(BUS_MAX, BUS_QTR, BUS_HLF):
    if BUS_MAX == 0 and BUS_QTR == 0:
        return 0.25
    else: 
        return 0""", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

    # Process: Calculate Field (14) (Calculate Field) (management)
    if MAX_INDEX_POINTS_16_ and MAX_INDEX_POINTS_7_ and MAX_INDEX_POINTS_9_:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            MAX_INDEX_POINTS_31_ = arcpy.management.CalculateField(in_table=MAX_INDEX_POINTS_27_, field="BUS_TOT", expression="!BUS_MAX! + !BUS_QTR! + !BUS_HLF!", expression_type="PYTHON3", code_block="", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

    # Process: Select Layer By Attribute (Select Layer By Attribute) (management)
    if MAX_INDEX_POINTS_16_ and MAX_INDEX_POINTS_31_ and MAX_INDEX_POINTS_7_ and MAX_INDEX_POINTS_9_:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            MAX_INDEX_POINTS_29_, Count_13_ = arcpy.management.SelectLayerByAttribute(in_layer_or_view=MAX_INDEX_POINTS_31_, selection_type="CLEAR_SELECTION", where_clause="", invert_where_clause="")

    # Process: Spatial Join (Spatial Join) (analysis)
    MMT_JOIN = f"{Workspace}\\MMT_JOIN"
    if MAX_INDEX_POINTS_16_ and MAX_INDEX_POINTS_29_ and MAX_INDEX_POINTS_31_ and MAX_INDEX_POINTS_7_ and MAX_INDEX_POINTS_9_:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            arcpy.analysis.SpatialJoin(target_features=MAX_INDEX_POINTS_34_, join_features=BikeShareLocations_2_, out_feature_class=MMT_JOIN, join_operation="JOIN_ONE_TO_ONE", join_type="KEEP_ALL", field_mapping="Shape_Length \"Shape_Length\" false true true 8 Double 0 0,First,#,MAX_INDEX_POINTS,Shape_Length,-1,-1;Shape_Area \"Shape_Area\" false true true 8 Double 0 0,First,#,MAX_INDEX_POINTS,Shape_Area,-1,-1;MMT_MAX \"MMT_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,MMT_MAX,-1,-1;MMT_QTR \"MMT_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,MMT_QTR,-1,-1;MMT_HLF \"MMT_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,MMT_HLF,-1,-1;MMT_TOT \"MMT_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,MMT_TOT,-1,-1;BRT_MAX \"BRT_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,BRT_MAX,-1,-1;BRT_QTR \"BRT_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,BRT_QTR,-1,-1;BRT_HLF \"BRT_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,BRT_HLF,-1,-1;BRT_TOT \"BRT_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,BRT_TOT,-1,-1;TIPP_MAX \"TIPP_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,TIPP_MAX,-1,-1;TIPP_QTR \"TIPP_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,TIPP_QTR,-1,-1;TIPP_HLF \"TIPP_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,TIPP_HLF,-1,-1;TIPP_TOT \"TIPP_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,TIPP_TOT,-1,-1;BUS_MAX \"BUS_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,BUS_MAX,-1,-1;BUS_QTR \"BUS_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,BUS_QTR,-1,-1;BUS_HLF \"BUS_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,BUS_HLF,-1,-1;BUS_TOT \"BUS_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,BUS_TOT,-1,-1;POINT_TOT \"POINT_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,POINT_TOT,-1,-1;NAME \"NAME\" true true false 50 Text 0 0,First,#,POINTS\\BikeShareLocations,NAME,0,50;LOCATION \"LOCATION\" true true false 120 Text 0 0,First,#,POINTS\\BikeShareLocations,LOCATION,0,120;INTRSECT \"INTRSECT\" true true false 80 Text 0 0,First,#,POINTS\\BikeShareLocations,INTRSECT,0,80;Count \"Count\" true true false 2 Short 0 0,First,#,POINTS\\BikeShareLocations,Count,-1,-1", match_option="COMPLETELY_CONTAINS", search_radius="", distance_field_name="")

    # Process: Add Join (Add Join) (management)
    if MAX_INDEX_POINTS_16_ and MAX_INDEX_POINTS_29_ and MAX_INDEX_POINTS_31_ and MAX_INDEX_POINTS_7_ and MAX_INDEX_POINTS_9_ and MMT_JOIN:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            MAX_INDEX_POINTS_35_ = arcpy.management.AddJoin(in_layer_or_view=MAX_INDEX_POINTS_34_, in_field="OBJECTID", join_table=MMT_JOIN, join_field="OBJECTID", join_type="KEEP_ALL", index_join_fields="NO_INDEX_JOIN_FIELDS")[0]

    # Process: Calculate Field (18) (Calculate Field) (management)
    if MAX_INDEX_POINTS_16_ and MAX_INDEX_POINTS_29_ and MAX_INDEX_POINTS_31_ and MAX_INDEX_POINTS_7_ and MAX_INDEX_POINTS_9_ and MMT_JOIN:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            MAX_INDEX_POINTS_38_ = arcpy.management.CalculateField(in_table=MAX_INDEX_POINTS_35_, field="MAX_INDEX_POINTS.MMT_TOT", expression="calc_field(!MAX_INDEX_POINTS.MMT_TOT!,!MMT_JOIN.Join_Count!)", expression_type="PYTHON3", code_block="""def calc_field(MMT_TOT, JOIN_COUNT):
    if JOIN_COUNT == 0:
        return(1 * MMT_TOT)
    else:
        return(MMT_TOT * JOIN_COUNT)""", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

    # Process: Remove Join (Remove Join) (management)
    if MAX_INDEX_POINTS_16_ and MAX_INDEX_POINTS_29_ and MAX_INDEX_POINTS_31_ and MAX_INDEX_POINTS_7_ and MAX_INDEX_POINTS_9_ and MMT_JOIN:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            Layer_With_Join_Removed = arcpy.management.RemoveJoin(in_layer_or_view=MAX_INDEX_POINTS_38_, join_name="MMT_JOIN")[0]

    # Process: Spatial Join (2) (Spatial Join) (analysis)
    BRT_JOIN = f"{Workspace}\\BRT_JOIN"
    if Layer_With_Join_Removed and MAX_INDEX_POINTS_16_ and MAX_INDEX_POINTS_29_ and MAX_INDEX_POINTS_31_ and MAX_INDEX_POINTS_7_ and MAX_INDEX_POINTS_9_ and MMT_JOIN:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            arcpy.analysis.SpatialJoin(target_features=MAX_INDEX_POINTS_33_, join_features=BRT_Stations_2_, out_feature_class=BRT_JOIN, join_operation="JOIN_ONE_TO_ONE", join_type="KEEP_ALL", field_mapping="Shape_Length \"Shape_Length\" false true true 8 Double 0 0,First,#,MAX_INDEX_POINTS,Shape_Length,-1,-1;Shape_Area \"Shape_Area\" false true true 8 Double 0 0,First,#,MAX_INDEX_POINTS,Shape_Area,-1,-1;MMT_MAX \"MMT_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,MMT_MAX,-1,-1;MMT_QTR \"MMT_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,MMT_QTR,-1,-1;MMT_HLF \"MMT_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,MMT_HLF,-1,-1;MMT_TOT \"MMT_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,MMT_TOT,-1,-1;BRT_MAX \"BRT_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,BRT_MAX,-1,-1;BRT_QTR \"BRT_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,BRT_QTR,-1,-1;BRT_HLF \"BRT_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,BRT_HLF,-1,-1;BRT_TOT \"BRT_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,BRT_TOT,-1,-1;TIPP_MAX \"TIPP_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,TIPP_MAX,-1,-1;TIPP_QTR \"TIPP_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,TIPP_QTR,-1,-1;TIPP_HLF \"TIPP_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,TIPP_HLF,-1,-1;TIPP_TOT \"TIPP_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,TIPP_TOT,-1,-1;BUS_MAX \"BUS_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,BUS_MAX,-1,-1;BUS_QTR \"BUS_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,BUS_QTR,-1,-1;BUS_HLF \"BUS_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,BUS_HLF,-1,-1;BUS_TOT \"BUS_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,BUS_TOT,-1,-1;POINT_TOT \"POINT_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,POINT_TOT,-1,-1;OID_ \"OID_\" true true false 4 Long 0 0,First,#,POINTS\\BRT_Stations,OID_,-1,-1;Name \"Name\" true true false 254 Text 0 0,First,#,POINTS\\BRT_Stations,Name,0,254;SymbolID \"SymbolID\" true true false 4 Long 0 0,First,#,POINTS\\BRT_Stations,SymbolID,-1,-1;Level_of_I \"Level_of_I\" true true false 50 Text 0 0,First,#,POINTS\\BRT_Stations,Level_of_I,0,50;Count \"Count\" true true false 2 Short 0 0,First,#,POINTS\\BRT_Stations,Count,-1,-1", match_option="COMPLETELY_CONTAINS", search_radius="", distance_field_name="")

    # Process: Add Join (2) (Add Join) (management)
    if BRT_JOIN and Layer_With_Join_Removed and MAX_INDEX_POINTS_16_ and MAX_INDEX_POINTS_29_ and MAX_INDEX_POINTS_31_ and MAX_INDEX_POINTS_7_ and MAX_INDEX_POINTS_9_ and MMT_JOIN:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            MAX_INDEX_POINTS_37_ = arcpy.management.AddJoin(in_layer_or_view=MAX_INDEX_POINTS_33_, in_field="OBJECTID", join_table=BRT_JOIN, join_field="OBJECTID", join_type="KEEP_ALL", index_join_fields="NO_INDEX_JOIN_FIELDS")[0]

    # Process: Calculate Field (19) (Calculate Field) (management)
    if BRT_JOIN and Layer_With_Join_Removed and MAX_INDEX_POINTS_16_ and MAX_INDEX_POINTS_29_ and MAX_INDEX_POINTS_31_ and MAX_INDEX_POINTS_7_ and MAX_INDEX_POINTS_9_ and MMT_JOIN:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            MAX_INDEX_POINTS_36_ = arcpy.management.CalculateField(in_table=MAX_INDEX_POINTS_37_, field="MAX_INDEX_POINTS.BRT_TOT", expression="calc_field(!MAX_INDEX_POINTS.BRT_TOT!,!BRT_JOIN.Join_Count!)", expression_type="PYTHON3", code_block="""def calc_field(BRT_TOT, JOIN_COUNT):
    if JOIN_COUNT == 0:
        return(1 * BRT_TOT)
    else:
        return(BRT_TOT * JOIN_COUNT)""", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

    # Process: Remove Join (2) (Remove Join) (management)
    if BRT_JOIN and Layer_With_Join_Removed and MAX_INDEX_POINTS_16_ and MAX_INDEX_POINTS_29_ and MAX_INDEX_POINTS_31_ and MAX_INDEX_POINTS_7_ and MAX_INDEX_POINTS_9_ and MMT_JOIN:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            Layer_With_Join_Removed_2_ = arcpy.management.RemoveJoin(in_layer_or_view=MAX_INDEX_POINTS_36_, join_name="BRT_JOIN")[0]

    # Process: Spatial Join (3) (Spatial Join) (analysis)
    TIPP_JOIN = f"{Workspace}\\TIPP_JOIN"
    if BRT_JOIN and Layer_With_Join_Removed and Layer_With_Join_Removed_2_ and MAX_INDEX_POINTS_16_ and MAX_INDEX_POINTS_29_ and MAX_INDEX_POINTS_31_ and MAX_INDEX_POINTS_7_ and MAX_INDEX_POINTS_9_ and MMT_JOIN:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            arcpy.analysis.SpatialJoin(target_features=MAX_INDEX_POINTS_32_, join_features=TIP_Points_WConstruction_2_, out_feature_class=TIPP_JOIN, join_operation="JOIN_ONE_TO_ONE", join_type="KEEP_ALL", field_mapping="Shape_Length \"Shape_Length\" false true true 8 Double 0 0,First,#,MAX_INDEX_POINTS,Shape_Length,-1,-1;Shape_Area \"Shape_Area\" false true true 8 Double 0 0,First,#,MAX_INDEX_POINTS,Shape_Area,-1,-1;MMT_MAX \"MMT_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,MMT_MAX,-1,-1;MMT_QTR \"MMT_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,MMT_QTR,-1,-1;MMT_HLF \"MMT_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,MMT_HLF,-1,-1;MMT_TOT \"MMT_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,MMT_TOT,-1,-1;BRT_MAX \"BRT_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,BRT_MAX,-1,-1;BRT_QTR \"BRT_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,BRT_QTR,-1,-1;BRT_HLF \"BRT_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,BRT_HLF,-1,-1;BRT_TOT \"BRT_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,BRT_TOT,-1,-1;TIPP_MAX \"TIPP_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,TIPP_MAX,-1,-1;TIPP_QTR \"TIPP_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,TIPP_QTR,-1,-1;TIPP_HLF \"TIPP_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,TIPP_HLF,-1,-1;TIPP_TOT \"TIPP_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,TIPP_TOT,-1,-1;BUS_MAX \"BUS_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,BUS_MAX,-1,-1;BUS_QTR \"BUS_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,BUS_QTR,-1,-1;BUS_HLF \"BUS_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,BUS_HLF,-1,-1;BUS_TOT \"BUS_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,BUS_TOT,-1,-1;POINT_TOT \"POINT_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,POINT_TOT,-1,-1;PROJECT_ID \"PROJECT_ID\" true true false 255 Text 0 0,First,#,POINTS\\TIP_Points_WConstruction,PROJECT_ID,0,255;PROJECT_NA \"PROJECT_NA\" true true false 255 Text 0 0,First,#,POINTS\\TIP_Points_WConstruction,PROJECT_NA,0,255;PIC_URL \"PIC_URL\" true true false 255 Text 0 0,First,#,POINTS\\TIP_Points_WConstruction,PIC_URL,0,255;WEBSITE \"WEBSITE\" true true false 8 Double 0 0,First,#,POINTS\\TIP_Points_WConstruction,WEBSITE,-1,-1;TIPTYPE \"TIPTYPE\" true true false 50 Text 0 0,First,#,POINTS\\TIP_Points_WConstruction,TIPTYPE,0,50;FWDPIN_NOTES \"NOTES\" true true false 255 Text 0 0,First,#,POINTS\\TIP_Points_WConstruction,FWDPIN_NOTES,0,255;FWDPIN_ATTACH \"Attachment\" true true false 50 Text 0 0,First,#,POINTS\\TIP_Points_WConstruction,FWDPIN_ATTACH,0,50;DISPLAY_YN \"DISPLAY Y or N\" true true false 5 Text 0 0,First,#,POINTS\\TIP_Points_WConstruction,DISPLAY_YN,0,5;FWDPIN_YEAR \"FWD P PROGRAM YEAR\" true true false 2 Short 0 0,First,#,POINTS\\TIP_Points_WConstruction,FWDPIN_YEAR,-1,-1;CREATED_USER \"CREATED_USER\" true true false 255 Text 0 0,First,#,POINTS\\TIP_Points_WConstruction,CREATED_USER,0,255;CREATED_DATE \"CREATED_DATE\" true true false 8 Date 0 0,First,#,POINTS\\TIP_Points_WConstruction,CREATED_DATE,-1,-1;LAST_EDITED_USER \"LAST_EDITED_USER\" true true false 255 Text 0 0,First,#,POINTS\\TIP_Points_WConstruction,LAST_EDITED_USER,0,255;LAST_EDITED_DATE \"LAST_EDITED_DATE\" true true false 8 Date 0 0,First,#,POINTS\\TIP_Points_WConstruction,LAST_EDITED_DATE,-1,-1;PROJECT_YEAR \"PROJECT_YEAR\" true true false 2 Short 0 0,First,#,POINTS\\TIP_Points_WConstruction,PROJECT_YEAR,-1,-1;TYPE_OTHER \"TYPE_OTHER\" true true false 50 Text 0 0,First,#,POINTS\\TIP_Points_WConstruction,TYPE_OTHER,0,50;PROJECT_STARTDATE \"Project Start Date\" true true false 8 Date 0 0,First,#,POINTS\\TIP_Points_WConstruction,PROJECT_STARTDATE,-1,-1;PROJECTPHASE \"Project Phase\" true true false 255 Text 0 0,First,#,POINTS\\TIP_Points_WConstruction,PROJECTPHASE,0,255;PROJECTPHASECOST \"Project Phase Cost\" true true false 255 Text 0 0,First,#,POINTS\\TIP_Points_WConstruction,PROJECTPHASECOST,0,255;PROJECTTOTALCOST \"Project Total Cost\" true true false 255 Text 0 0,First,#,POINTS\\TIP_Points_WConstruction,PROJECTTOTALCOST,0,255;DESCRIPTION \"Description\" true true false 255 Text 0 0,First,#,POINTS\\TIP_Points_WConstruction,DESCRIPTION,0,255;COMMENTS \"Additional Comments\" true true false 255 Text 0 0,First,#,POINTS\\TIP_Points_WConstruction,COMMENTS,0,255;CONSTCOMPLETEDATE \"Construction Complete Date\" true true false 5 Text 0 0,First,#,POINTS\\TIP_Points_WConstruction,CONSTCOMPLETEDATE,0,5;PROJECTPHCOMPLETEDATE \"Project Phase Complete Date\" true true false 25 Text 0 0,First,#,POINTS\\TIP_Points_WConstruction,PROJECTPHCOMPLETEDATE,0,25;Count \"Count\" true true false 2 Short 0 0,First,#,POINTS\\TIP_Points_WConstruction,Count,-1,-1", match_option="COMPLETELY_CONTAINS", search_radius="", distance_field_name="")

    # Process: Add Join (3) (Add Join) (management)
    if BRT_JOIN and Layer_With_Join_Removed and Layer_With_Join_Removed_2_ and MAX_INDEX_POINTS_16_ and MAX_INDEX_POINTS_29_ and MAX_INDEX_POINTS_31_ and MAX_INDEX_POINTS_7_ and MAX_INDEX_POINTS_9_ and MMT_JOIN and TIPP_JOIN:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            MAX_INDEX_POINTS_39_ = arcpy.management.AddJoin(in_layer_or_view=MAX_INDEX_POINTS_32_, in_field="OBJECTID", join_table=TIPP_JOIN, join_field="OBJECTID", join_type="KEEP_ALL", index_join_fields="NO_INDEX_JOIN_FIELDS")[0]

    # Process: Calculate Field (20) (Calculate Field) (management)
    if BRT_JOIN and Layer_With_Join_Removed and Layer_With_Join_Removed_2_ and MAX_INDEX_POINTS_16_ and MAX_INDEX_POINTS_29_ and MAX_INDEX_POINTS_31_ and MAX_INDEX_POINTS_7_ and MAX_INDEX_POINTS_9_ and MMT_JOIN and TIPP_JOIN:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            MAX_INDEX_POINTS_44_ = arcpy.management.CalculateField(in_table=MAX_INDEX_POINTS_39_, field="MAX_INDEX_POINTS.TIPP_TOT", expression="calc_field(!MAX_INDEX_POINTS.TIPP_TOT!,!TIPP_JOIN.Join_Count!)", expression_type="PYTHON3", code_block="""def calc_field(TIPP_TOT, JOIN_COUNT):
    if JOIN_COUNT == 0:
        return(1 * TIPP_TOT)
    else:
        return(TIPP_TOT * JOIN_COUNT)""", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

    # Process: Remove Join (3) (Remove Join) (management)
    if BRT_JOIN and Layer_With_Join_Removed and Layer_With_Join_Removed_2_ and MAX_INDEX_POINTS_16_ and MAX_INDEX_POINTS_29_ and MAX_INDEX_POINTS_31_ and MAX_INDEX_POINTS_7_ and MAX_INDEX_POINTS_9_ and MMT_JOIN and TIPP_JOIN:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            Layer_With_Join_Removed_3_ = arcpy.management.RemoveJoin(in_layer_or_view=MAX_INDEX_POINTS_44_, join_name="TIPP_JOIN")[0]

    # Process: Spatial Join (4) (Spatial Join) (analysis)
    BUS_JOIN = f"{Workspace}\\BUS_JOIN"
    if BRT_JOIN and Layer_With_Join_Removed and Layer_With_Join_Removed_2_ and Layer_With_Join_Removed_3_ and MAX_INDEX_POINTS_16_ and MAX_INDEX_POINTS_29_ and MAX_INDEX_POINTS_31_ and MAX_INDEX_POINTS_7_ and MAX_INDEX_POINTS_9_ and MMT_JOIN and TIPP_JOIN:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            arcpy.analysis.SpatialJoin(target_features=MAX_INDEX_POINTS_22_, join_features=PSTA_Bus_Stops_2_, out_feature_class=BUS_JOIN, join_operation="JOIN_ONE_TO_ONE", join_type="KEEP_ALL", field_mapping="Shape_Length \"Shape_Length\" false true true 8 Double 0 0,First,#,MAX_INDEX_POINTS,Shape_Length,-1,-1;Shape_Area \"Shape_Area\" false true true 8 Double 0 0,First,#,MAX_INDEX_POINTS,Shape_Area,-1,-1;MMT_MAX \"MMT_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,MMT_MAX,-1,-1;MMT_QTR \"MMT_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,MMT_QTR,-1,-1;MMT_HLF \"MMT_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,MMT_HLF,-1,-1;MMT_TOT \"MMT_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,MMT_TOT,-1,-1;BRT_MAX \"BRT_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,BRT_MAX,-1,-1;BRT_QTR \"BRT_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,BRT_QTR,-1,-1;BRT_HLF \"BRT_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,BRT_HLF,-1,-1;BRT_TOT \"BRT_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,BRT_TOT,-1,-1;TIPP_MAX \"TIPP_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,TIPP_MAX,-1,-1;TIPP_QTR \"TIPP_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,TIPP_QTR,-1,-1;TIPP_HLF \"TIPP_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,TIPP_HLF,-1,-1;TIPP_TOT \"TIPP_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,TIPP_TOT,-1,-1;BUS_MAX \"BUS_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,BUS_MAX,-1,-1;BUS_QTR \"BUS_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,BUS_QTR,-1,-1;BUS_HLF \"BUS_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,BUS_HLF,-1,-1;BUS_TOT \"BUS_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,BUS_TOT,-1,-1;POINT_TOT \"POINT_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_POINTS,POINT_TOT,-1,-1;Stop \"Stop\" true true false 4 Long 0 0,First,#,POINTS\\PSTA_Bus_Stops,Stop,-1,-1;Routes__Co \"Routes__Co\" true true false 4 Long 0 0,First,#,POINTS\\PSTA_Bus_Stops,Routes__Co,-1,-1;Place \"Place\" true true false 254 Text 0 0,First,#,POINTS\\PSTA_Bus_Stops,Place,0,254;Descriptio \"Descriptio\" true true false 254 Text 0 0,First,#,POINTS\\PSTA_Bus_Stops,Descriptio,0,254;District \"District\" true true false 254 Text 0 0,First,#,POINTS\\PSTA_Bus_Stops,District,0,254;Routes \"Routes\" true true false 254 Text 0 0,First,#,POINTS\\PSTA_Bus_Stops,Routes,0,254;Signp \"Signp\" true true false 254 Text 0 0,First,#,POINTS\\PSTA_Bus_Stops,Signp,0,254;Trash_Cans \"Trash_Cans\" true true false 254 Text 0 0,First,#,POINTS\\PSTA_Bus_Stops,Trash_Cans,0,254;PSTAShelt \"PSTAShelt\" true true false 254 Text 0 0,First,#,POINTS\\PSTA_Bus_Stops,PSTAShelt,0,254;Cantilever \"Cantilever\" true true false 254 Text 0 0,First,#,POINTS\\PSTA_Bus_Stops,Cantilever,0,254;Gable \"Gable\" true true false 254 Text 0 0,First,#,POINTS\\PSTA_Bus_Stops,Gable,0,254;Barrel \"Barrel\" true true false 254 Text 0 0,First,#,POINTS\\PSTA_Bus_Stops,Barrel,0,254;AdShelter \"AdShelter\" true true false 254 Text 0 0,First,#,POINTS\\PSTA_Bus_Stops,AdShelter,0,254;LightedShe \"LightedShe\" true true false 254 Text 0 0,First,#,POINTS\\PSTA_Bus_Stops,LightedShe,0,254;OtherShelt \"OtherShelt\" true true false 254 Text 0 0,First,#,POINTS\\PSTA_Bus_Stops,OtherShelt,0,254;OnStreetDi \"OnStreetDi\" true true false 254 Text 0 0,First,#,POINTS\\PSTA_Bus_Stops,OnStreetDi,0,254;SolarLight \"SolarLight\" true true false 254 Text 0 0,First,#,POINTS\\PSTA_Bus_Stops,SolarLight,0,254;SimSeat \"SimSeat\" true true false 254 Text 0 0,First,#,POINTS\\PSTA_Bus_Stops,SimSeat,0,254;JCBench \"JCBench\" true true false 254 Text 0 0,First,#,POINTS\\PSTA_Bus_Stops,JCBench,0,254;PSTABench \"PSTABench\" true true false 254 Text 0 0,First,#,POINTS\\PSTA_Bus_Stops,PSTABench,0,254;LandingPad \"LandingPad\" true true false 254 Text 0 0,First,#,POINTS\\PSTA_Bus_Stops,LandingPad,0,254;Bike \"Bike\" true true false 254 Text 0 0,First,#,POINTS\\PSTA_Bus_Stops,Bike,0,254;OtherBench \"OtherBench\" true true false 254 Text 0 0,First,#,POINTS\\PSTA_Bus_Stops,OtherBench,0,254;IStop \"IStop\" true true false 254 Text 0 0,First,#,POINTS\\PSTA_Bus_Stops,IStop,0,254;Half_displ \"Half_displ\" true true false 254 Text 0 0,First,#,POINTS\\PSTA_Bus_Stops,Half_displ,0,254;Large_disp \"Large_disp\" true true false 254 Text 0 0,First,#,POINTS\\PSTA_Bus_Stops,Large_disp,0,254;Loca_longi \"Loca_longi\" true true false 8 Double 0 0,First,#,POINTS\\PSTA_Bus_Stops,Loca_longi,-1,-1;Loca_latit \"Loca_latit\" true true false 8 Double 0 0,First,#,POINTS\\PSTA_Bus_Stops,Loca_latit,-1,-1;Stop_ID \"Stop_ID\" true true false 4 Long 0 0,First,#,POINTS\\PSTA_Bus_Stops,Stop_ID,-1,-1;Stop_Name \"Stop_Name\" true true false 254 Text 0 0,First,#,POINTS\\PSTA_Bus_Stops,Stop_Name,0,254;On \"On\" true true false 4 Long 0 0,First,#,POINTS\\PSTA_Bus_Stops,On,-1,-1;Off \"Off\" true true false 4 Long 0 0,First,#,POINTS\\PSTA_Bus_Stops,Off,-1,-1;Final \"Final\" true true false 4 Long 0 0,First,#,POINTS\\PSTA_Bus_Stops,Final,-1,-1;LAT \"LAT\" true true false 8 Double 0 0,First,#,POINTS\\PSTA_Bus_Stops,LAT,-1,-1;LONG \"LONG\" true true false 8 Double 0 0,First,#,POINTS\\PSTA_Bus_Stops,LONG,-1,-1;RANK \"RANK\" true true false 4 Long 0 0,First,#,POINTS\\PSTA_Bus_Stops,RANK,-1,-1;All_Shelte \"All_Shelte\" true true false 8 Double 0 0,First,#,POINTS\\PSTA_Bus_Stops,All_Shelte,-1,-1;PSTA_All_S \"PSTA_All_S\" true true false 50 Text 0 0,First,#,POINTS\\PSTA_Bus_Stops,PSTA_All_S,0,50;Count \"Count\" true true false 2 Short 0 0,First,#,POINTS\\PSTA_Bus_Stops,Count,-1,-1;NEAR_FID \"NEAR_FID\" true true false 4 Long 0 0,First,#,POINTS\\PSTA_Bus_Stops,NEAR_FID,-1,-1;NEAR_DIST \"NEAR_DIST\" true true false 8 Double 0 0,First,#,POINTS\\PSTA_Bus_Stops,NEAR_DIST,-1,-1", match_option="COMPLETELY_CONTAINS", search_radius="", distance_field_name="")

    # Process: Add Join (4) (Add Join) (management)
    if BRT_JOIN and BUS_JOIN and Layer_With_Join_Removed and Layer_With_Join_Removed_2_ and Layer_With_Join_Removed_3_ and MAX_INDEX_POINTS_16_ and MAX_INDEX_POINTS_29_ and MAX_INDEX_POINTS_31_ and MAX_INDEX_POINTS_7_ and MAX_INDEX_POINTS_9_ and MMT_JOIN and TIPP_JOIN:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            MAX_INDEX_POINTS_41_ = arcpy.management.AddJoin(in_layer_or_view=MAX_INDEX_POINTS_22_, in_field="OBJECTID", join_table=BUS_JOIN, join_field="OBJECTID", join_type="KEEP_ALL", index_join_fields="NO_INDEX_JOIN_FIELDS")[0]

    # Process: Calculate Field (21) (Calculate Field) (management)
    if BRT_JOIN and BUS_JOIN and Layer_With_Join_Removed and Layer_With_Join_Removed_2_ and Layer_With_Join_Removed_3_ and MAX_INDEX_POINTS_16_ and MAX_INDEX_POINTS_29_ and MAX_INDEX_POINTS_31_ and MAX_INDEX_POINTS_7_ and MAX_INDEX_POINTS_9_ and MMT_JOIN and TIPP_JOIN:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            MAX_INDEX_POINTS_40_ = arcpy.management.CalculateField(in_table=MAX_INDEX_POINTS_41_, field="MAX_INDEX_POINTS.BUS_TOT", expression="calc_field(!MAX_INDEX_POINTS.BUS_TOT!,!BUS_JOIN.Join_Count!)", expression_type="PYTHON3", code_block="""def calc_field(BUS_TOT, JOIN_COUNT):
    if JOIN_COUNT == 0:
        return(1 * BUS_TOT)
    else:
        return(BUS_TOT * JOIN_COUNT)""", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

    # Process: Remove Join (4) (Remove Join) (management)
    if BRT_JOIN and BUS_JOIN and Layer_With_Join_Removed and Layer_With_Join_Removed_2_ and Layer_With_Join_Removed_3_ and MAX_INDEX_POINTS_16_ and MAX_INDEX_POINTS_29_ and MAX_INDEX_POINTS_31_ and MAX_INDEX_POINTS_7_ and MAX_INDEX_POINTS_9_ and MMT_JOIN and TIPP_JOIN:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            Layer_With_Join_Removed_4_ = arcpy.management.RemoveJoin(in_layer_or_view=MAX_INDEX_POINTS_40_, join_name="BUS_JOIN")[0]

    # Process: Calculate Field (22) (Calculate Field) (management)
    if BRT_JOIN and BUS_JOIN and Layer_With_Join_Removed and Layer_With_Join_Removed_2_ and Layer_With_Join_Removed_3_ and Layer_With_Join_Removed_4_ and MAX_INDEX_POINTS_16_ and MAX_INDEX_POINTS_29_ and MAX_INDEX_POINTS_31_ and MAX_INDEX_POINTS_7_ and MAX_INDEX_POINTS_9_ and MMT_JOIN and TIPP_JOIN:
        with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
            MAX_INDEX_POINTS_43_ = arcpy.management.CalculateField(in_table=Layer_With_Join_Removed_4_, field="POINT_TOT", expression="!MMT_TOT! + !BRT_TOT! + !TIPP_TOT! + !BUS_TOT!", expression_type="PYTHON3", code_block="", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

"""
PART 5:

Takes the EPA walkability Index that is isolated for the community you are working in and adds it as a factor in the overall MAX Index score. 
Finally this tool creates the final MAX Index and calculates the total MAX Index score for each quartermile grid. 
"""


walkabilityIndex = arcpy.GetParameterAsText(14) # input the EPA walkability index

def createMAXIndex():  # Creates the final MAX Index, walkability score, and total MAX score. 

    # To allow overwriting outputs change overwriteOutput option to True.
    arcpy.env.overwriteOutput = True

    # Model Environment settings
    with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
        MAX_INDEX_LINES_2_ = maxInputFeaturesLines
        MAX_INDEX_POINTS = maxInputFeaturesPoints
        MAX_INDEX_UPDATE_gdb = Workspace
        Walkability_Pinellas_Grid = walkabilityIndex

        # Process: Add Join (Add Join) (management)
        MAX_INDEX_LINES = arcpy.management.AddJoin(in_layer_or_view=MAX_INDEX_LINES_2_, in_field="OBJECTID", join_table=MAX_INDEX_POINTS, join_field="OBJECTID", join_type="KEEP_ALL", index_join_fields="NO_INDEX_JOIN_FIELDS")[0]

        # Process: Feature Class To Feature Class (Feature Class To Feature Class) (conversion)
        MAX_INDEX_FINAL = arcpy.conversion.FeatureClassToFeatureClass(in_features=MAX_INDEX_LINES, out_path=MAX_INDEX_UPDATE_gdb, out_name="MAX_INDEX_FINAL", where_clause="", field_mapping="BL_MAX \"BL_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_LINES.BL_MAX,-1,-1;BL_QTR \"BL_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_LINES.BL_QTR,-1,-1;BL_HLF \"BL_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_LINES.BL_HLF,-1,-1;BL_TOT \"BL_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_LINES.BL_TOT,-1,-1;HW_MAX \"HW_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_LINES.HW_MAX,-1,-1;HW_QTR \"HW_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_LINES.HW_QTR,-1,-1;HW_HLF \"HW_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_LINES.HW_HLF,-1,-1;HW_TOT \"HW_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_LINES.HW_TOT,-1,-1;LOS_MAX \"LOS_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_LINES.LOS_MAX,-1,-1;LOS_QTR \"LOS_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_LINES.LOS_QTR,-1,-1;LOS_HLF \"LOS_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_LINES.LOS_HLF,-1,-1;LOS_TOT \"LOS_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_LINES.LOS_TOT,-1,-1;VC_MAX \"VC_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_LINES.VC_MAX,-1,-1;VC_QTR \"VC_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_LINES.VC_QTR,-1,-1;VC_HLF \"VC_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_LINES.VC_HLF,-1,-1;VC_TOT \"VC_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_LINES.VC_TOT,-1,-1;TIPL_MAX \"TIPL_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_LINES.TIPL_MAX,-1,-1;TIPL_QTR \"TIPL_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_LINES.TIPL_QTR,-1,-1;TIPL_HLF \"TIPL_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_LINES.TIPL_HLF,-1,-1;TIPL_TOT \"TIPL_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_LINES.TIPL_TOT,-1,-1;TRL_MAX \"TRL_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_LINES.TRL_MAX,-1,-1;TRL_QTR \"TRL_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_LINES.TRL_QTR,-1,-1;TRL_HLF \"TRL_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_LINES.TRL_HLF,-1,-1;TRL_TOT \"TRL_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_LINES.TRL_TOT,-1,-1;SHR_MAX \"SHR_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_LINES.SHR_MAX,-1,-1;SHR_QTR \"SHR_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_LINES.SHR_QTR,-1,-1;SHR_HLF \"SHR_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_LINES.SHR_HLF,-1,-1;SHR_TOT \"SHR_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_LINES.SHR_TOT,-1,-1;TOT_LIN \"TOT_LIN\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_LINES.TOT_LIN,-1,-1;MMT_MAX \"MMT_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_POINTS.MMT_MAX,-1,-1;MMT_QTR \"MMT_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_POINTS.MMT_QTR,-1,-1;MMT_HLF \"MMT_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_POINTS.MMT_HLF,-1,-1;MMT_TOT \"MMT_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_POINTS.MMT_TOT,-1,-1;BRT_MAX \"BRT_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_POINTS.BRT_MAX,-1,-1;BRT_QTR \"BRT_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_POINTS.BRT_QTR,-1,-1;BRT_HLF \"BRT_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_POINTS.BRT_HLF,-1,-1;BRT_TOT \"BRT_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_POINTS.BRT_TOT,-1,-1;TIPP_MAX \"TIPP_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_POINTS.TIPP_MAX,-1,-1;TIPP_QTR \"TIPP_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_POINTS.TIPP_QTR,-1,-1;TIPP_HLF \"TIPP_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_POINTS.TIPP_HLF,-1,-1;TIPP_TOT \"TIPP_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_POINTS.TIPP_TOT,-1,-1;BUS_MAX \"BUS_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_POINTS.BUS_MAX,-1,-1;BUS_QTR \"BUS_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_POINTS.BUS_QTR,-1,-1;BUS_HLF \"BUS_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_POINTS.BUS_HLF,-1,-1;BUS_TOT \"BUS_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_POINTS.BUS_TOT,-1,-1;POINT_TOT \"POINT_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_LINES,MAX_INDEX_POINTS.POINT_TOT,-1,-1", config_keyword="")[0]

        # Process: Remove Join (Remove Join) (management)
        if MAX_INDEX_FINAL:
            Layer_With_Join_Removed = arcpy.management.RemoveJoin(in_layer_or_view=MAX_INDEX_LINES, join_name="MAX_INDEX_POINTS")[0]

        # Process: Add Field (Add Field) (management)
        MAX_INDEX_FINAL_2_ = arcpy.management.AddField(in_table=MAX_INDEX_FINAL, field_name="TOT_SCORE", field_type="DOUBLE", field_precision=4, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

        # Process: Calculate Field (Calculate Field) (management)
        MAX_INDEX_FINAL_3_ = arcpy.management.CalculateField(in_table=MAX_INDEX_FINAL_2_, field="TOT_SCORE", expression="!TOT_LIN! + !POINT_TOT!", expression_type="PYTHON3", code_block="", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Add Field (2) (Add Field) (management)
        if MAX_INDEX_FINAL_3_:
            MAX_INDEX_FINAL_5_ = arcpy.management.AddField(in_table=MAX_INDEX_FINAL_3_, field_name="WLK_TOT", field_type="DOUBLE", field_precision=6, field_scale=None, field_length=None, field_alias="", field_is_nullable="NULLABLE", field_is_required="NON_REQUIRED", field_domain="")[0]

        # Process: Calculate Field (2) (Calculate Field) (management)
        if MAX_INDEX_FINAL_3_:
            MAX_INDEX_FINAL_6_ = arcpy.management.CalculateField(in_table=MAX_INDEX_FINAL_5_, field="WLK_TOT", expression="0", expression_type="PYTHON3", code_block="", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Spatial Join (Spatial Join) (analysis)
        WLK_JOIN = f"{Workspace}\\WLK_JOIN"
        if MAX_INDEX_FINAL_3_:
            arcpy.analysis.SpatialJoin(target_features=MAX_INDEX_FINAL_6_, join_features=Walkability_Pinellas_Grid, out_feature_class=WLK_JOIN, join_operation="JOIN_ONE_TO_ONE", join_type="KEEP_ALL", field_mapping="BL_MAX \"BL_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,BL_MAX,-1,-1;BL_QTR \"BL_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,BL_QTR,-1,-1;BL_HLF \"BL_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,BL_HLF,-1,-1;BL_TOT \"BL_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,BL_TOT,-1,-1;HW_MAX \"HW_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,HW_MAX,-1,-1;HW_QTR \"HW_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,HW_QTR,-1,-1;HW_HLF \"HW_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,HW_HLF,-1,-1;HW_TOT \"HW_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,HW_TOT,-1,-1;LOS_MAX \"LOS_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,LOS_MAX,-1,-1;LOS_QTR \"LOS_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,LOS_QTR,-1,-1;LOS_HLF \"LOS_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,LOS_HLF,-1,-1;LOS_TOT \"LOS_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,LOS_TOT,-1,-1;VC_MAX \"VC_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,VC_MAX,-1,-1;VC_QTR \"VC_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,VC_QTR,-1,-1;VC_HLF \"VC_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,VC_HLF,-1,-1;VC_TOT \"VC_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,VC_TOT,-1,-1;TIPL_MAX \"TIPL_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,TIPL_MAX,-1,-1;TIPL_QTR \"TIPL_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,TIPL_QTR,-1,-1;TIPL_HLF \"TIPL_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,TIPL_HLF,-1,-1;TIPL_TOT \"TIPL_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,TIPL_TOT,-1,-1;TRL_MAX \"TRL_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,TRL_MAX,-1,-1;TRL_QTR \"TRL_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,TRL_QTR,-1,-1;TRL_HLF \"TRL_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,TRL_HLF,-1,-1;TRL_TOT \"TRL_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,TRL_TOT,-1,-1;SHR_MAX \"SHR_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,SHR_MAX,-1,-1;SHR_QTR \"SHR_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,SHR_QTR,-1,-1;SHR_HLF \"SHR_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,SHR_HLF,-1,-1;SHR_TOT \"SHR_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,SHR_TOT,-1,-1;TOT_LIN \"TOT_LIN\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,TOT_LIN,-1,-1;MMT_MAX \"MMT_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,MMT_MAX,-1,-1;MMT_QTR \"MMT_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,MMT_QTR,-1,-1;MMT_HLF \"MMT_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,MMT_HLF,-1,-1;MMT_TOT \"MMT_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,MMT_TOT,-1,-1;BRT_MAX \"BRT_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,BRT_MAX,-1,-1;BRT_QTR \"BRT_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,BRT_QTR,-1,-1;BRT_HLF \"BRT_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,BRT_HLF,-1,-1;BRT_TOT \"BRT_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,BRT_TOT,-1,-1;TIPP_MAX \"TIPP_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,TIPP_MAX,-1,-1;TIPP_QTR \"TIPP_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,TIPP_QTR,-1,-1;TIPP_HLF \"TIPP_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,TIPP_HLF,-1,-1;TIPP_TOT \"TIPP_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,TIPP_TOT,-1,-1;BUS_MAX \"BUS_MAX\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,BUS_MAX,-1,-1;BUS_QTR \"BUS_QTR\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,BUS_QTR,-1,-1;BUS_HLF \"BUS_HLF\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,BUS_HLF,-1,-1;BUS_TOT \"BUS_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,BUS_TOT,-1,-1;POINT_TOT \"POINT_TOT\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,POINT_TOT,-1,-1;Shape_Length \"Shape_Length\" false true true 8 Double 0 0,First,#,MAX_INDEX_FINAL,Shape_Length,-1,-1;Shape_Area \"Shape_Area\" false true true 8 Double 0 0,First,#,MAX_INDEX_FINAL,Shape_Area,-1,-1;TOT_SCORE \"TOT_SCORE\" true true false 8 Double 0 0,First,#,MAX_INDEX_FINAL,TOT_SCORE,-1,-1;WLK_TOT \"WLK_TOT\" true true false 0 Double 6 12,First,#,MAX_INDEX_FINAL,WLK_TOT,-1,-1;GEOID10 \"GEOID10\" true true false 12 Text 0 0,First,#,Walkability_Pinellas_Grid,GEOID10,0,12;TRFIPS \"TRFIPS\" true true false 254 Text 0 0,First,#,Walkability_Pinellas_Grid,TRFIPS,0,254;CFIPS \"CFIPS\" true true false 254 Text 0 0,First,#,Walkability_Pinellas_Grid,CFIPS,0,254;SFIPS \"SFIPS\" true true false 254 Text 0 0,First,#,Walkability_Pinellas_Grid,SFIPS,0,254;CSA \"CSA\" true true false 254 Text 0 0,First,#,Walkability_Pinellas_Grid,CSA,0,254;CSA_Name \"CSA_Name\" true true false 254 Text 0 0,First,#,Walkability_Pinellas_Grid,CSA_Name,0,254;CBSA \"CBSA\" true true false 8 Double 0 0,First,#,Walkability_Pinellas_Grid,CBSA,-1,-1;CBSA_Name \"CBSA_Name\" true true false 254 Text 0 0,First,#,Walkability_Pinellas_Grid,CBSA_Name,0,254;COUNTHU10 \"COUNTHU10\" true true false 8 Double 0 0,First,#,Walkability_Pinellas_Grid,COUNTHU10,-1,-1;TOTPOP10 \"TOTPOP10\" true true false 8 Double 0 0,First,#,Walkability_Pinellas_Grid,TOTPOP10,-1,-1;HH \"HH\" true true false 8 Double 0 0,First,#,Walkability_Pinellas_Grid,HH,-1,-1;WORKERS \"WORKERS\" true true false 8 Double 0 0,First,#,Walkability_Pinellas_Grid,WORKERS,-1,-1;AC_TOT \"AC_TOT\" true true false 8 Double 0 0,First,#,Walkability_Pinellas_Grid,AC_TOT,-1,-1;AC_WATER \"AC_WATER\" true true false 8 Double 0 0,First,#,Walkability_Pinellas_Grid,AC_WATER,-1,-1;AC_LAND \"AC_LAND\" true true false 8 Double 0 0,First,#,Walkability_Pinellas_Grid,AC_LAND,-1,-1;AC_UNPR \"AC_UNPR\" true true false 4 Float 0 0,First,#,Walkability_Pinellas_Grid,AC_UNPR,-1,-1;D2A_EPHHM \"D2A_EPHHM\" true true false 8 Double 0 0,First,#,Walkability_Pinellas_Grid,D2A_EPHHM,-1,-1;D2B_E8MIXA \"D2B_E8MIXA\" true true false 8 Double 0 0,First,#,Walkability_Pinellas_Grid,D2B_E8MIXA,-1,-1;D3b \"D3b\" true true false 8 Double 0 0,First,#,Walkability_Pinellas_Grid,D3b,-1,-1;D4a \"D4a\" true true false 8 Double 0 0,First,#,Walkability_Pinellas_Grid,D4a,-1,-1;D2A_Ranked \"D2A_Ranked\" true true false 4 Long 0 0,First,#,Walkability_Pinellas_Grid,D2A_Ranked,-1,-1;D2B_Ranked \"D2B_Ranked\" true true false 4 Long 0 0,First,#,Walkability_Pinellas_Grid,D2B_Ranked,-1,-1;D4A_Ranked \"D4A_Ranked\" true true false 4 Long 0 0,First,#,Walkability_Pinellas_Grid,D4A_Ranked,-1,-1;D3B_Ranked \"D3B_Ranked\" true true false 4 Long 0 0,First,#,Walkability_Pinellas_Grid,D3B_Ranked,-1,-1;NatWalkInd \"NatWalkInd\" true true false 8 Double 0 0,First,#,Walkability_Pinellas_Grid,NatWalkInd,-1,-1;Shape_Leng \"Shape_Leng\" true true false 8 Double 0 0,First,#,Walkability_Pinellas_Grid,Shape_Leng,-1,-1;Shape_Length_1 \"Shape_Length\" false true true 8 Double 0 0,First,#,Walkability_Pinellas_Grid,Shape_Length,-1,-1;Shape_Area_1 \"Shape_Area\" false true true 8 Double 0 0,First,#,Walkability_Pinellas_Grid,Shape_Area,-1,-1", match_option="INTERSECT", search_radius="", distance_field_name="")

        # Process: Add Join (2) (Add Join) (management)
        if MAX_INDEX_FINAL_3_ and WLK_JOIN:
            MAX_INDEX_FINAL_7_ = arcpy.management.AddJoin(in_layer_or_view=MAX_INDEX_FINAL_6_, in_field="OBJECTID", join_table=WLK_JOIN, join_field="OBJECTID", join_type="KEEP_ALL", index_join_fields="NO_INDEX_JOIN_FIELDS")[0]

        # Process: Calculate Field (3) (Calculate Field) (management)
        if MAX_INDEX_FINAL_3_ and WLK_JOIN:
            MAX_INDEX_FINAL_8_ = arcpy.management.CalculateField(in_table=MAX_INDEX_FINAL_7_, field="MAX_INDEX_FINAL.WLK_TOT", expression="calc_field(!MAX_INDEX_FINAL.WLK_TOT!,!WLK_JOIN.NatWalkInd!)", expression_type="PYTHON3", code_block="""def calc_field(WLK_TOT, WLK_INDX):
    if WLK_INDX >= 13:
        return 2
    else:
        return 0""", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

        # Process: Remove Join (2) (Remove Join) (management)
        if MAX_INDEX_FINAL_3_ and WLK_JOIN:
            Layer_With_Join_Removed_2_ = arcpy.management.RemoveJoin(in_layer_or_view=MAX_INDEX_FINAL_8_, join_name="WLK_JOIN")[0]

        # Process: Calculate Field (4) (Calculate Field) (management)
        if MAX_INDEX_FINAL_3_ and WLK_JOIN:
            MAX_INDEX_FINAL_9_ = arcpy.management.CalculateField(in_table=Layer_With_Join_Removed_2_, field="TOT_SCORE", expression="!TOT_SCORE! + !WLK_TOT!", expression_type="PYTHON3", code_block="", field_type="TEXT", enforce_domains="NO_ENFORCE_DOMAINS")[0]

if __name__ == '__main__':
    # Global Environment settings
    with arcpy.EnvManager(scratchWorkspace=Workspace, workspace=Workspace):
        createFieldsLines()
        calculateFieldsLines()
        createFieldsPoints()
        calculateFieldsPoints()
        createMAXIndex()
