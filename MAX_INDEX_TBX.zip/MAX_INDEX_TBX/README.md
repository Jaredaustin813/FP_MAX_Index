# MAX Index (Multimodal Accessibility Index)

Included in these folders are the MAX Index toolbox (tbx file) that you will need to download and connect to in ArcMap 10.x, or ArcGIS pro. 

Information on how to do this can be found here:

ArcGIS Pro: https://pro.arcgis.com/en/pro-app/latest/help/projects/connect-to-a-toolbox.htm

ArcMap: https://desktop.arcgis.com/en/arcmap/latest/analyze/managing-tools-and-toolboxes/adding-tools.htm

## Getting Started

Once connected to the MAX_INDEX_v2 toolbox you will need to select the dropdown to the left of the toolbox to display the 
MAX_INDEX_v2 script. Right click the script and navigate down to and select "Properties" from the window. 

Once properties is open you will need to navigate to "Execution" and import the downloaded MAX_INDEX_v2.py file and click OK. 
The tool should now be functional. 

## Test Data

The tool parameters detailed above can be run on your own data or on sample data that is provided with the tool. The sample data is from Pinellas County, Florida. 

To run the sample data, connect to the provided MAX_INDEX_TEST.gdb, and use the associated data as the inputs for the tool detailed above. 

For information on how to add a geodatabase (gdb) to your work environment please see the following resources:

ArcGIS Pro: https://pro.arcgis.com/en/pro-app/latest/help/projects/connect-to-a-database.htm

ArcMap: https://desktop.arcgis.com/en/arcmap/10.3/manage-data/using-arccatalog/connect-to-file-or-personal-geodatabase.htm

## Customization

The MAX_INDEX_v2.py file can me modified to make your own changes to what the tool imports as parameters (perhaps highspeed rail instead of bus rapid transit, etc.) 
and how it weights various inputs (2 points for bike lanes instead of 3 points, etc.). 

## IMPORTANT

The MAX Index was built to run off of feature classes imported from a file geodatabase (gdb) if you wish to deploy the MAX Index in your community please ensure 
all data sets used as inputs into the tool are in the same file geodatabase to avoid error.

Additionally, an attached pdf titled "MAX Index - Getting Started" is available and serves as a step by step guid for setting up the initial quarter mile (can be modified 
for your community as needed) grids for your community based on available parcel data. This pdf details information that is CRITICAL for successful deployment 
of the MAX Index tool. Rest assured, however, that the creation of the fishnet data is the most labor intensive portion of the MAX Index, clocking in at roughly 5-10 minutes.

